#pragma once

#include <cstdint>
#include <vector>

// Data structures are kept identical to the original togh ESP so esp.cpp
// (the visual part) can be used without any changes.
struct Vec3 {
    float x = 0.0f;
    float y = 0.0f;
    float z = 0.0f;
};

struct Player {
    int index = 0;
    int health = 0;
    int team = 0;
    bool teammate = false;
    bool spotted = false;
    Vec3 origin{};
    Vec3 mins{};
    Vec3 maxs{};
    float distance = 0.0f;
    char name[64] = {};

    bool hasBones = false;
    Vec3 bones[16];
};

struct GameDiag {
    uintptr_t entityList = 0;
    uintptr_t controller = 0;
    uintptr_t localPawn = 0;
    uint32_t entityStride = 0;
    int strideScore = 0;
    int highestEntityIndex = -1;
    int players = 0;
};

// ONETAP is a Unity IL2CPP game, so there are no cs2-dumper JSON offsets.
// The data provider attaches to the IL2CPP runtime in-process and converts
// Unity camera / bot data into the same Player layout the ESP expects.
class Game {
public:
    bool Init(void* gameModule, int width, int height);
    void SetViewport(int width, int height);

    bool Ready() const;
    void Update();
    void CollectPlayers(std::vector<Player>& out);
    bool ReadViewMatrix(float out[16]) const;

    uintptr_t LocalPawn() const;
    const GameDiag& Diag() const { return diag_; }

private:
    int width_ = 1920;
    int height_ = 1080;
    bool ready_ = false;
    GameDiag diag_{};
};
