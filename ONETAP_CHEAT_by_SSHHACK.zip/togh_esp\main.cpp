// togh ESP visuals for ONETAP (Unity IL2CPP).
// The ESP drawing code (esp.cpp) and the menu (ui.cpp) are used unchanged;
// only the data provider is ONETAP-specific.
#include <windows.h>
#include <d3d11.h>
#include <dxgi.h>

#include <cstdarg>
#include <cstdio>
#include <cmath>

#include "imgui.h"
#include "imgui_impl_win32.h"
#include "imgui_impl_dx11.h"

#include "config.h"
#include "esp.h"
#include "game.h"
#include "ui.h"
#include "onetap_il2cpp.h"

extern IMGUI_IMPL_API LRESULT ImGui_ImplWin32_WndProcHandler(HWND, UINT, WPARAM, LPARAM);

namespace {

const char* kLogPath = "C:\\Users\\dwad1\\AppData\\Local\\Temp\\opencode\\onetap_togh.log";

Config g_cfg;
Game g_game;
ImFont* g_font = nullptr;
bool g_running = true;
bool g_hooked = false;
bool g_inited = false;
bool g_gameReady = false;
int g_width = 1920;
int g_height = 1080;
HMODULE g_self = nullptr;
HWND g_hwnd = nullptr;

ID3D11Device* g_dev = nullptr;
ID3D11DeviceContext* g_dc = nullptr;
ID3D11RenderTargetView* g_rtv = nullptr;

typedef HRESULT(WINAPI* t_Present)(IDXGISwapChain*, UINT, UINT);
typedef HRESULT(WINAPI* t_Resize)(IDXGISwapChain*, UINT, UINT, DXGI_FORMAT, UINT);
t_Present o_Present = nullptr;
t_Resize o_Resize = nullptr;

typedef LRESULT(CALLBACK* t_WndProc)(HWND, UINT, WPARAM, LPARAM);
t_WndProc o_WndProc = nullptr;

void Log(const char* fmt, ...) {
    FILE* f = nullptr;
    if (fopen_s(&f, kLogPath, "a") != 0 || !f) return;
    va_list ap;
    va_start(ap, fmt);
    vfprintf(f, fmt, ap);
    va_end(ap);
    fputc('\n', f);
    fclose(f);
}

bool KeyPressed(int vk) {
    static bool prev[256] = {};
    const bool down = (GetAsyncKeyState(vk) & 0x8000) != 0;
    const bool pressed = down && !prev[vk & 0xFF];
    prev[vk & 0xFF] = down;
    return pressed;
}

LRESULT CALLBACK hk_WndProc(HWND h, UINT m, WPARAM w, LPARAM l) {
    if (m == WM_KEYDOWN && !(l & 0x40000000)) {
        if (w == VK_INSERT) {
            g_cfg.menuVisible = !g_cfg.menuVisible;
            Log("[key] INSERT menu=%d", (int)g_cfg.menuVisible);
            return 0;
        }
        if (w == VK_F8) {
            g_cfg.enabled = !g_cfg.enabled;
            Log("[key] F8 esp=%d", (int)g_cfg.enabled);
            return 0;
        }
        if (w == VK_END) {
            g_running = false;
            return 0;
        }
    }
    if (g_inited && g_cfg.menuVisible && ImGui_ImplWin32_WndProcHandler(h, m, w, l)) {
        return 1;  // menu consumes input, the game doesn't see it
    }
    if (!o_WndProc) return DefWindowProcA(h, m, w, l);
    return CallWindowProcA(o_WndProc, h, m, w, l);
}

bool InitImGui(IDXGISwapChain* sc) {
    if (g_inited) return true;
    DXGI_SWAP_CHAIN_DESC sd{};
    if (FAILED(sc->GetDesc(&sd))) return false;
    g_width = sd.BufferDesc.Width ? static_cast<int>(sd.BufferDesc.Width) : 1920;
    g_height = sd.BufferDesc.Height ? static_cast<int>(sd.BufferDesc.Height) : 1080;
    if (FAILED(sc->GetDevice(__uuidof(ID3D11Device), reinterpret_cast<void**>(&g_dev)))) return false;
    g_dev->GetImmediateContext(&g_dc);
    if (!g_dc) return false;

    ImGui::CreateContext();
    ImGuiIO& io = ImGui::GetIO();
    io.IniFilename = nullptr;
    ImGui::StyleColorsDark();
    io.Fonts->AddFontFromFileTTF("C:\\Windows\\Fonts\\segoeui.ttf", 16.0f, nullptr,
                                 io.Fonts->GetGlyphRangesCyrillic());
    if (io.Fonts->Fonts.empty()) io.Fonts->AddFontDefault();
    g_font = io.Fonts->Fonts[0];
    io.DisplaySize = ImVec2(static_cast<float>(g_width), static_cast<float>(g_height));

    g_hwnd = sd.OutputWindow;
    ImGui_ImplWin32_Init(g_hwnd);
    ImGui_ImplDX11_Init(g_dev, g_dc);
    if (g_hwnd && !o_WndProc) {
        o_WndProc = reinterpret_cast<t_WndProc>(SetWindowLongPtrA(g_hwnd, GWLP_WNDPROC, reinterpret_cast<LONG_PTR>(hk_WndProc)));
    }
    g_inited = true;
    g_game.SetViewport(g_width, g_height);
    Log("[imgui] init %dx%d hwnd=%p", g_width, g_height, (void*)g_hwnd);
    return true;
}

void ShutdownImGui() {
    if (!g_inited) return;
    g_inited = false;
    if (g_hwnd && o_WndProc) {
        SetWindowLongPtrA(g_hwnd, GWLP_WNDPROC, reinterpret_cast<LONG_PTR>(o_WndProc));
        o_WndProc = nullptr;
    }
    ImGui_ImplDX11_Shutdown();
    ImGui_ImplWin32_Shutdown();
    ImGui::DestroyContext();
    if (g_rtv) { g_rtv->Release(); g_rtv = nullptr; }
    if (g_dc) { g_dc->Release(); g_dc = nullptr; }
    if (g_dev) { g_dev->Release(); g_dev = nullptr; }
}

ID3D11RenderTargetView* GetRtv(IDXGISwapChain* sc) {
    if (g_rtv) return g_rtv;
    ID3D11Texture2D* bb = nullptr;
    if (SUCCEEDED(sc->GetBuffer(0, __uuidof(ID3D11Texture2D), reinterpret_cast<void**>(&bb))) && bb) {
        g_dev->CreateRenderTargetView(bb, nullptr, &g_rtv);
        bb->Release();
    }
    return g_rtv;
}

void Frame(IDXGISwapChain* sc) {
    if (!InitImGui(sc)) return;

    if (!g_gameReady) {
        static DWORD lastTry = 0;
        const DWORD now = GetTickCount();
        if (now - lastTry > 1000) {
            lastTry = now;
            HMODULE ga = GetModuleHandleA("GameAssembly.dll");
            if (ga) {
                g_gameReady = g_game.Init(ga, g_width, g_height);
                Log("[game] init=%d", (int)g_gameReady);
            }
        }
    }

    static std::vector<Player> players;
    float view[16] = {};
    EspStats stats;

    if (g_gameReady) {
        g_game.Update();
        static DWORD lastScan = 0;
        const DWORD now = GetTickCount();
        const DWORD period = 1000u / static_cast<DWORD>(std::fmax(10.0f, std::fmin(240.0f, (float)g_cfg.dataHz)));
        if (now - lastScan >= period) {
            lastScan = now;
            if (g_cfg.enabled) g_game.CollectPlayers(players);
        }
        if (g_cfg.enabled) g_game.ReadViewMatrix(view);
    }

    ImGui_ImplDX11_NewFrame();
    ImGui_ImplWin32_NewFrame();
    ImGui::NewFrame();

    if (g_cfg.enabled && g_gameReady && view[15] != 0.0f) {
        DrawEsp(ImGui::GetBackgroundDrawList(), players, view, g_width, g_height, g_cfg, g_font, stats);
    }
    static DWORD lastEspLog = 0;
    if (g_gameReady && GetTickCount() - lastEspLog > 3000) {
        lastEspLog = GetTickCount();
        Log("[esp] players=%d drawn=%d view_w=%.2f", stats.total, stats.drawn, view[15]);
    }

    if (g_cfg.menuVisible) {
        MenuInfo info;
        info.attached = g_gameReady;
        info.offsetsLoaded = g_gameReady;
        info.offsetsError = g_gameReady ? "" : "IL2CPP not ready";
        info.pid = GetCurrentProcessId();
        info.clientBase = reinterpret_cast<uintptr_t>(GetModuleHandleA("GameAssembly.dll"));
        info.localPawn = g_game.LocalPawn();
        info.stride = 0;
        info.strideScore = 0;
        info.players = stats.total;
        info.drawn = stats.drawn;
        info.fps = ImGui::GetIO().Framerate;
        DrawMenu(g_cfg, info);
    }

    ImGui::Render();
    ID3D11RenderTargetView* rtv = GetRtv(sc);
    if (rtv) {
        g_dc->OMSetRenderTargets(1, &rtv, nullptr);
        ImGui_ImplDX11_RenderDrawData(ImGui::GetDrawData());
    }
}

HRESULT WINAPI hk_Present(IDXGISwapChain* sc, UINT sync, UINT flags) {
    if (g_hooked && g_running) {
        try { Frame(sc); }
        catch (...) { Log("[error] exception in frame"); }
    }
    return o_Present ? o_Present(sc, sync, flags) : E_FAIL;
}

HRESULT WINAPI hk_Resize(IDXGISwapChain* sc, UINT w, UINT h, DXGI_FORMAT f, UINT s) {
    ShutdownImGui();
    return o_Resize ? o_Resize(sc, w, h, f, s) : E_FAIL;
}

static DWORD WINAPI InstallThread(LPVOID) {
    Sleep(2000);  // leave the loader lock before touching the CRT
    Log("[install] start");
    for (int i = 0; i < 120; ++i) {
        if (GetModuleHandleA("GameAssembly.dll") && GetModuleHandleA("d3d11.dll")) break;
        Sleep(1000);
    }

    IDXGISwapChain* dummy = nullptr;
    ID3D11Device* dev = nullptr;
    ID3D11DeviceContext* ctx = nullptr;
    D3D_FEATURE_LEVEL fl{};
    DXGI_SWAP_CHAIN_DESC sd{};
    sd.BufferCount = 1;
    sd.BufferDesc.Width = 1;
    sd.BufferDesc.Height = 1;
    sd.BufferDesc.Format = DXGI_FORMAT_R8G8B8A8_UNORM;
    sd.BufferUsage = DXGI_USAGE_RENDER_TARGET_OUTPUT;
    sd.OutputWindow = GetDesktopWindow();
    sd.SampleDesc.Count = 1;
    sd.Windowed = TRUE;
    IDXGIFactory* factory = nullptr;
    CreateDXGIFactory(__uuidof(IDXGIFactory), reinterpret_cast<void**>(&factory));
    D3D11CreateDeviceAndSwapChain(nullptr, D3D_DRIVER_TYPE_HARDWARE, nullptr, 0, nullptr, 0,
                                  D3D11_SDK_VERSION, &sd, &dummy, &dev, &fl, &ctx);
    if (!dummy) {
        Log("[install] no dummy swapchain");
        if (dev) dev->Release();
        if (ctx) ctx->Release();
        if (factory) factory->Release();
        return 0;
    }

    void** vt = *reinterpret_cast<void***>(dummy);
    DWORD old = 0;
    VirtualProtect(&vt[8], sizeof(void*), PAGE_READWRITE, &old);
    o_Present = reinterpret_cast<t_Present>(vt[8]);
    vt[8] = reinterpret_cast<void*>(hk_Present);
    VirtualProtect(&vt[8], sizeof(void*), old, &old);
    VirtualProtect(&vt[13], sizeof(void*), PAGE_READWRITE, &old);
    o_Resize = reinterpret_cast<t_Resize>(vt[13]);
    vt[13] = reinterpret_cast<void*>(hk_Resize);
    VirtualProtect(&vt[13], sizeof(void*), old, &old);
    g_hooked = true;
    Log("[install] Present hooked");

    if (dev) dev->Release();
    if (ctx) ctx->Release();
    if (dummy) dummy->Release();
    if (factory) factory->Release();
    return 0;
}

}  // namespace

// Used by the copied IL2CPP state header.
void logf2(const char* fmt, ...) {
    FILE* f = nullptr;
    if (fopen_s(&f, kLogPath, "a") != 0 || !f) return;
    va_list ap;
    va_start(ap, fmt);
    vfprintf(f, fmt, ap);
    va_end(ap);
    fputc('\n', f);
    fclose(f);
}

BOOL APIENTRY DllMain(HMODULE h, DWORD reason, LPVOID) {
    if (reason == DLL_PROCESS_ATTACH) {
        g_self = h;
        DisableThreadLibraryCalls(h);
        CreateThread(nullptr, 0, InstallThread, nullptr, 0, nullptr);
    }
    return TRUE;
}
