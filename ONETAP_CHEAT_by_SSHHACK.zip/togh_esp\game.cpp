#include "game.h"

#include <cmath>
#include <cstring>

#include "onetap_il2cpp.h"
#include "onetap_game.h"

namespace {

inline Vec3 ToVec(const Vector3& v) { return Vec3{v.x, v.y, v.z}; }

Vector3 ReadTransformVector(Il2CppObject* transform, const char* getter) {
    Vector3 out{};
    if (!transform || !getter) return out;
    Il2CppClass* c = il2cpp_object_get_class(transform);
    Il2CppMethod* m = c ? il2cpp_class_get_method_from_name(c, getter, 0) : nullptr;
    if (!m) return out;
    // Value-type getters return garbage through runtime_invoke in this IL2CPP
    // build (same problem as get_position_Injected), so call methodPointer.
    void* mp = methodPtr(m);
    if (!mp) return out;
    typedef void(__cdecl* fn_vec)(Vector3* ret, void* self, void* methodInfo);
    ((fn_vec)mp)(&out, transform, static_cast<void*>(m));
    return out;
}

Il2CppMethod* PositionGetter() {
    static Il2CppMethod* m = nullptr;
    if (!m) {
        Il2CppClass* c = getClass("UnityEngine.CoreModule", "UnityEngine", "Transform");
        if (c) m = il2cpp_class_get_method_from_name(c, "get_position_Injected", 1);
    }
    return m;
}

bool ReadWorldPosition(Il2CppObject* transform, Vector3& out) {
    Il2CppMethod* m = PositionGetter();
    if (!transform || !m) return false;
    void* args[1] = {&out};
    return invokeSafe(m, transform, args);
}

inline float Distance(const Vec3& a, const Vec3& b) {
    const float dx = a.x - b.x, dy = a.y - b.y, dz = a.z - b.z;
    return std::sqrt(dx * dx + dy * dy + dz * dz);
}

}  // namespace

bool Game::Init(void* gameModule, int width, int height) {
    width_ = width;
    height_ = height;
    HMODULE mod = static_cast<HMODULE>(gameModule);
    if (!loadIl2Cpp(mod)) return false;
    initGame(mod, width_, height_);
    il2cpp_thread_attach(il2cpp_domain_get());
    ready_ = true;
    return true;
}

void Game::SetViewport(int width, int height) {
    width_ = width > 0 ? width : 1920;
    height_ = height > 0 ? height : 1080;
}

bool Game::Ready() const { return ready_; }

uintptr_t Game::LocalPawn() const { return reinterpret_cast<uintptr_t>(g.movement); }

void Game::Update() {
    if (!ready_) return;
    if (il2cpp_thread_attach && il2cpp_domain_get()) il2cpp_thread_attach(il2cpp_domain_get());
    ensureGame();
    refreshCamera(0.f);
}

void Game::CollectPlayers(std::vector<Player>& out) {
    out.clear();
    diag_.players = 0;
    if (!ready_) return;

    const Vec3 camPos = ToVec(getCamPos(g.camera));
    diag_.localPawn = reinterpret_cast<uintptr_t>(g.movement);

    if (!g.gameObj) return;
    Il2CppObject* targets = getFieldObj(g.gameObj, "targets", off::GameTargets);
    if (!targets) return;

    Il2CppClass* cls = il2cpp_object_get_class(targets);
    Il2CppField* listField = cls ? il2cpp_class_get_field_from_name(cls, "targets") : nullptr;
    Il2CppList* list = nullptr;
    if (listField) il2cpp_field_get_value(targets, listField, &list);
    if (!list || list->size <= 0 || list->size > 64 || !list->items) return;

    const uintptr_t data = reinterpret_cast<uintptr_t>(list->items) + off::Il2CppArrayData;
    static const char* boneNames[9] = {
        "head", "chest", "pelvis", "armLeft", "armRight",
        "thighLeft", "thighRight", "shinLeft", "shinRight"
    };

    for (int i = 0; i < list->size; ++i) {
        Il2CppObject* bot = *reinterpret_cast<Il2CppObject**>(data + i * sizeof(void*));
        if (!bot) continue;

        bool active = true;
        getField(bot, "active", &active, 1);
        if (!active) continue;

        Vector3 feet{};
        getField(bot, "spawn", &feet, sizeof(feet));
        if (!std::isfinite(feet.x) || !std::isfinite(feet.y) || !std::isfinite(feet.z)) continue;

        float hp = 0.f;
        getField(bot, "health", &hp, sizeof(hp));

        Player p{};
        p.index = i + 1;
        p.health = static_cast<int>(hp);
        p.team = 2;
        p.teammate = false;
        p.spotted = true;  // no fog-of-war in the offline arena
        p.origin = ToVec(feet);
        p.origin.y += 0.80f;
        p.mins = Vec3{-0.35f, -0.80f, -0.35f};
        p.maxs = Vec3{0.35f, 0.85f, 0.35f};
        p.distance = Distance(camPos, p.origin);

        Il2CppString* title = nullptr;
        getField(bot, "title", &title, sizeof(void*));
        const std::string name = strOf(title);
        if (!name.empty() && name.size() < sizeof(p.name)) {
            std::strncpy(p.name, name.c_str(), sizeof(p.name) - 1);
        } else {
            std::snprintf(p.name, sizeof(p.name), "BOT %d", i + 1);
        }

        Il2CppObject* animator = nullptr;
        getField(bot, "animator", &animator, sizeof(void*));
        if (animator) {
            Vector3 world[9] = {};
            int found = 0;
            for (int b = 0; b < 9; ++b) {
                Il2CppObject* tr = nullptr;
                getField(animator, boneNames[b], &tr, sizeof(void*));
                if (ReadWorldPosition(tr, world[b])) ++found;
            }
            if (found >= 6) {
                const Vec3 head = ToVec(world[0]);
                const Vec3 chest = ToVec(world[1]);
                const Vec3 pelvis = ToVec(world[2]);
                const Vec3 armL = ToVec(world[3]);
                const Vec3 armR = ToVec(world[4]);
                const Vec3 thighL = ToVec(world[5]);
                const Vec3 thighR = ToVec(world[6]);
                const Vec3 shinL = ToVec(world[7]);
                const Vec3 shinR = ToVec(world[8]);
                const Vec3 foot = p.origin;

                p.bones[0] = head;
                p.bones[1] = Vec3{(head.x + chest.x) * 0.5f, (head.y + chest.y) * 0.5f, (head.z + chest.z) * 0.5f};
                p.bones[2] = chest;
                p.bones[3] = pelvis;
                p.bones[4] = armL;
                p.bones[5] = armL;
                p.bones[6] = armL;
                p.bones[7] = armR;
                p.bones[8] = armR;
                p.bones[9] = armR;
                p.bones[10] = thighL;
                p.bones[11] = shinL;
                p.bones[12] = foot;
                p.bones[13] = thighR;
                p.bones[14] = shinR;
                p.bones[15] = foot;
                p.hasBones = true;
            }
        }

        out.push_back(p);
    }
    diag_.players = static_cast<int>(out.size());

    static DWORD lastDiag = 0;
    if (!out.empty() && GetTickCount() - lastDiag > 3000) {
        lastDiag = GetTickCount();
        float m[16] = {};
        if (ReadViewMatrix(m)) {
            const Player& p = out[0];
            auto project = [&](const Vec3& v, float& w) {
                w = m[12] * v.x + m[13] * v.y + m[14] * v.z + m[15];
                if (w < 0.01f) return Vec3{-1.f, -1.f, 0.f};
                const float x = m[0] * v.x + m[1] * v.y + m[2] * v.z + m[3];
                const float y = m[4] * v.x + m[5] * v.y + m[6] * v.z + m[7];
                return Vec3{width_ * 0.5f * (x / w + 1.f), height_ * 0.5f * (1.f - y / w), 1.f};
            };
            float wCenter = 0.f;
            const Vec3 center = project(p.origin, wCenter);
            float wMin = 0.f;
            const Vec3 corner = project(Vec3{p.origin.x + p.mins.x, p.origin.y + p.mins.y, p.origin.z + p.mins.z}, wMin);
            logf2("[bot] pos=(%.1f,%.1f,%.1f) dist=%.1f hp=%d bones=%d center=(%.0f,%.0f) w=%.2f corner=(%.0f,%.0f) wc=%.2f",
                  p.origin.x, p.origin.y, p.origin.z, p.distance, p.health, (int)p.hasBones,
                  center.x, center.y, wCenter, corner.x, corner.y, wMin);
        }
    }
}

bool Game::ReadViewMatrix(float out[16]) const {
    if (!ready_ || !g.camera) return false;

    const Vector3 camPos = getCamPos(g.camera);
    const Vector3 forward = getCamForward(g.camera);
    Il2CppObject* transform = invokeObjSafe(g.mCamGetTransform, g.camera, nullptr);
    Vector3 right = ReadTransformVector(transform, "get_right");
    Vector3 up = ReadTransformVector(transform, "get_up");

    const float len = std::sqrt(forward.x * forward.x + forward.y * forward.y + forward.z * forward.z);
    if (len < 0.001f) return false;

    if (std::sqrt(right.x * right.x + right.y * right.y + right.z * right.z) < 0.001f ||
        std::sqrt(up.x * up.x + up.y * up.y + up.z * up.z) < 0.001f) {
        // Unity is left-handed: right = up(world) x forward, up = forward x right.
        right = Vector3{forward.z, 0.0f, -forward.x};
        const float rl = std::sqrt(right.x * right.x + right.z * right.z);
        if (rl > 0.001f) { right.x /= rl; right.z /= rl; }
        up = Vector3{forward.y * right.z - forward.z * right.y,
                     forward.z * right.x - forward.x * right.z,
                     forward.x * right.y - forward.y * right.x};
    }

    float fov = g.fov;
    if (!std::isfinite(fov) || fov < 10.f || fov > 179.f) fov = 90.f;
    const float tanHalf = std::tan(fov * 0.5f * 3.14159265f / 180.f);
    if (tanHalf < 0.001f) return false;
    const float aspect = static_cast<float>(width_) / static_cast<float>(height_);

    const auto dot = [](const Vector3& a, const Vector3& b) {
        return a.x * b.x + a.y * b.y + a.z * b.z;
    };

    // Row-major clip matrix: clip = view * vec4(world.x, world.y, world.z, 1).
    // clip.w is the camera-space depth, matching esp.cpp's w > 0.01 check.
    const float invTan = 1.0f / tanHalf;
    const float invTanAspect = invTan / aspect;

    for (int i = 0; i < 16; ++i) out[i] = 0.0f;
    out[0] = right.x * invTanAspect;
    out[1] = right.y * invTanAspect;
    out[2] = right.z * invTanAspect;
    out[3] = -dot(right, camPos) * invTanAspect;

    out[4] = up.x * invTan;
    out[5] = up.y * invTan;
    out[6] = up.z * invTan;
    out[7] = -dot(up, camPos) * invTan;

    out[12] = forward.x;
    out[13] = forward.y;
    out[14] = forward.z;
    out[15] = -dot(forward, camPos);

    // One-time sanity check: compare our projection with the game's own
    // WorldToScreenPoint. Appears in the log as [w2s].
    static bool tested = false;
    if (!tested) {
        tested = true;
        const Vector3 probe{camPos.x + forward.x * 10.0f,
                            camPos.y + forward.y * 10.0f,
                            camPos.z + forward.z * 10.0f};
        const Vector3 unity = w2s(g.camera, probe);
        const float w = out[12] * probe.x + out[13] * probe.y + out[14] * probe.z + out[15];
        if (w > 0.01f) {
            const float x = out[0] * probe.x + out[1] * probe.y + out[2] * probe.z + out[3];
            const float y = out[4] * probe.x + out[5] * probe.y + out[6] * probe.z + out[7];
            const float sx = width_ * 0.5f * (x / w + 1.0f);
            const float sy = height_ * 0.5f * (1.0f - y / w);
            logf2("[w2s] unity=(%.1f,%.1f,%.1f) mine=(%.1f,%.1f) w=%.2f fov=%.1f",
                  unity.x, unity.y, unity.z, sx, sy, w, fov);
        } else {
            logf2("[w2s] bad w=%.2f fov=%.1f", w, fov);
        }
    }
    return true;
}
