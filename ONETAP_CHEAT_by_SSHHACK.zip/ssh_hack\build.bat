@echo off
call "C:\Program Files\Microsoft Visual Studio\18\Professional\VC\Auxiliary\Build\vcvars64.bat" >nul 2>&1
if errorlevel 1 (echo vcvars64 failed & exit /b 1)
cd /d "%~dp0"
set NL=%~dp0nl_menu
set NLF=%NL:\=/%
cl /nologo /utf-8 /O2 /std:c++20 /EHsc /I. /Iimgui /Iimgui\backends /DNDEBUG ^
  /DKAMSHAKO_PORTABLE_MENU /DIMGUI_DEFINE_MATH_OPERATORS /DNOMINMAX /D_CRT_SECURE_NO_WARNINGS ^
  /I"%NL%" /I"%NL%\third_party" ^
  /DMENU_ASSET_DIR=\"%NLF%/assets\" ^
  main.cpp ^
  imgui\imgui.cpp imgui\imgui_draw.cpp imgui\imgui_tables.cpp imgui\imgui_widgets.cpp ^
  imgui\backends\imgui_impl_win32.cpp imgui\backends\imgui_impl_dx11.cpp ^
  "%NL%\assets.cpp" "%NL%\font_data.cpp" ^
  "%NL%\menu\agent_models_data.cpp" "%NL%\menu\agent_models_lookup.cpp" ^
  "%NL%\menu\ambience.cpp" "%NL%\menu\backdrop.cpp" "%NL%\menu\binds.cpp" ^
  "%NL%\menu\blur.cpp" "%NL%\menu\boot.cpp" "%NL%\menu\config.cpp" ^
  "%NL%\menu\draw.cpp" "%NL%\menu\esp_model.cpp" "%NL%\menu\esp_preview.cpp" ^
  "%NL%\menu\fonts.cpp" "%NL%\menu\images.cpp" "%NL%\menu\inventory.cpp" ^
  "%NL%\menu\inventory_catalog.cpp" "%NL%\menu\inventory_ids.cpp" ^
  "%NL%\menu\map_catalog_data.cpp" "%NL%\menu\map_catalog_lookup.cpp" ^
  "%NL%\menu\map_preview.cpp" "%NL%\menu\menu.cpp" "%NL%\menu\model_catalog.cpp" ^
  "%NL%\menu\model_preview.cpp" "%NL%\menu\panel.cpp" "%NL%\menu\popup.cpp" ^
  "%NL%\menu\presets.cpp" "%NL%\menu\search.cpp" "%NL%\menu\search_overlay.cpp" ^
  "%NL%\menu\sky_list.cpp" "%NL%\menu\tabs.cpp" "%NL%\menu\visuals.cpp" ^
  "%NL%\menu\watermark.cpp" "%NL%\menu\widgets.cpp" ^
  /link /DLL /OUT:ssh_hack.dll user32.lib d3d11.lib dxgi.lib imm32.lib d3dcompiler.lib > build.log 2>&1
if errorlevel 1 (type build.log & exit /b 1)
echo BUILD OK: ssh_hack.dll
