#pragma once

#include <vector>

#include "config.h"
#include "game.h"
#include "imgui.h"

struct EspStats {
    int total = 0;
    int drawn = 0;
};

bool WorldToScreen(const float view[16], const Vec3& world, ImVec2& out, int width, int height);

void DrawEsp(ImDrawList* drawList, const std::vector<Player>& players, const float view[16],
             int width, int height, const Config& cfg, ImFont* font, EspStats& stats);
