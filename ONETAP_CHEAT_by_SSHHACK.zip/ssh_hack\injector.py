"""RustX ESP injector — inject DLL into the game process with Ham.dll loaded."""
import ctypes
from ctypes import wintypes as w
import os, sys

k32 = ctypes.WinDLL('kernel32', use_last_error=True)
psapi = ctypes.WinDLL('psapi', use_last_error=True)

PROCESS_ALL_ACCESS = 0x1F0FFF
PROCESS_QUERY_INFORMATION = 0x0400
PROCESS_VM_READ = 0x0010
MEM_COMMIT, MEM_RESERVE, PAGE_READWRITE = 0x1000, 0x2000, 0x04

def declare(dll, name, restype, *args):
    fn = getattr(dll, name); fn.restype, fn.argtypes = restype, list(args); return fn

OpenProcess = declare(k32, 'OpenProcess', w.HANDLE, w.DWORD, w.BOOL, w.DWORD)
CloseHandle = declare(k32, 'CloseHandle', w.BOOL, w.HANDLE)
VirtualAllocEx = declare(k32, 'VirtualAllocEx', ctypes.c_void_p, w.HANDLE, ctypes.c_void_p,
                         ctypes.c_size_t, w.DWORD, w.DWORD)
WriteProcessMemory = declare(k32, 'WriteProcessMemory', w.BOOL, w.HANDLE, ctypes.c_void_p,
                             ctypes.c_void_p, ctypes.c_size_t, ctypes.POINTER(ctypes.c_size_t))
GetProcAddress = declare(k32, 'GetProcAddress', ctypes.c_void_p, w.HMODULE, ctypes.c_char_p)
GetModuleHandleA = declare(k32, 'GetModuleHandleA', w.HMODULE, ctypes.c_char_p)
CreateRemoteThread = getattr(k32, 'CreateRemoteThread')
CreateRemoteThread.argtypes = [w.HANDLE, ctypes.c_void_p, ctypes.c_size_t, ctypes.c_void_p,
                                ctypes.c_void_p, w.DWORD, ctypes.POINTER(w.DWORD)]
CreateRemoteThread.restype = w.HANDLE
WaitForSingleObject = declare(k32, 'WaitForSingleObject', w.DWORD, w.HANDLE, w.DWORD)
EnumProcesses = declare(psapi, 'EnumProcesses', w.BOOL, ctypes.POINTER(w.DWORD), w.DWORD, ctypes.POINTER(w.DWORD))
EnumProcessModules = declare(psapi, 'EnumProcessModules', w.BOOL, w.HANDLE, ctypes.POINTER(w.HMODULE),
                             w.DWORD, ctypes.POINTER(w.DWORD))
GetModuleBaseNameA = declare(psapi, 'GetModuleBaseNameA', w.DWORD, w.HANDLE, w.HMODULE, ctypes.c_char_p, w.DWORD)


def find_game():
    out = []
    arr = (w.DWORD * 4096)(); need = w.DWORD()
    if not EnumProcesses(arr, ctypes.sizeof(arr), ctypes.byref(need)):
        return out
    for pid in arr[:need.value // 4]:
        if not pid: continue
        h = OpenProcess(PROCESS_QUERY_INFORMATION | PROCESS_VM_READ, False, pid)
        if not h: continue
        try:
            mods = (w.HMODULE * 1500)(); cb = w.DWORD()
            if EnumProcessModules(h, mods, ctypes.sizeof(mods), ctypes.byref(cb)):
                for m in mods[:cb.value // ctypes.sizeof(w.HMODULE)]:
                    nm = ctypes.create_string_buffer(260)
                    if GetModuleBaseNameA(h, m, nm, 260) and nm.value.lower() in (b'gameassembly.dll', b'onetap.exe'):
                        out.append((pid, nm.value.decode())); break
        finally:
            CloseHandle(h)
    return out


def inject(pid, dll):
    dll = os.path.abspath(dll)
    if not os.path.isfile(dll): raise FileNotFoundError(dll)
    h = OpenProcess(PROCESS_ALL_ACCESS, False, pid)
    if not h: raise ctypes.WinError(ctypes.get_last_error())
    try:
        buf = dll.encode() + b'\x00'
        remote = VirtualAllocEx(h, None, len(buf), MEM_COMMIT | MEM_RESERVE, PAGE_READWRITE)
        if not remote: raise ctypes.WinError(ctypes.get_last_error())
        wr = ctypes.c_size_t()
        if not WriteProcessMemory(h, remote, buf, len(buf), ctypes.byref(wr)):
            raise ctypes.WinError(ctypes.get_last_error())
        loadlib = GetProcAddress(GetModuleHandleA(b'kernel32.dll'), b'LoadLibraryA')
        th = CreateRemoteThread(h, None, 0, loadlib, remote, 0, None)
        if not th: raise ctypes.WinError(ctypes.get_last_error())
        WaitForSingleObject(th, 10000); CloseHandle(th)
        print('[+] injected', dll, 'into PID', pid)
    finally:
        CloseHandle(h)


if __name__ == '__main__':
    dll = sys.argv[1] if len(sys.argv) > 1 else os.path.join(os.path.dirname(__file__), 'src', 'rustx_esp_new.dll')
    procs = find_game()
    if not procs:
        print('[-] game not running'); sys.exit(1)
    print('found', procs)
    for pid, nm in procs:
        try: inject(pid, dll); break
        except Exception as e: print('[-] fail', pid, e)
