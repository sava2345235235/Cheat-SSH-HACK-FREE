#pragma once
#include "config.h"
#include "game.h"
#include <imgui/imgui.h>
#include <cmath>

namespace esp {

// Body proportions from Onetap.Targets (dump.cs).
namespace bone {
    constexpr float Head = 1.54f, Neck = 1.45f, Waist = 1.12f,
                    Hip = 0.86f, Knee = 0.47f, Feet = 0.0f;
}

static unsigned int rainbowColor(float speed = 1.0f) {
    float t = ImGui::GetTime() * speed;
    return ImGui::ColorConvertFloat4ToU32(ImVec4(0.5f + 0.5f*sinf(t),
        0.5f + 0.5f*sinf(t + 2.094f), 0.5f + 0.5f*sinf(t + 4.188f), 1.f));
}
static inline unsigned int pickColor(const PlayerInfo& p) {
    if (g_cfg.rainbow) return rainbowColor();
    if (p.local) return g_cfg.colLocal;
    return g_cfg.colEnemy;
}

static void textGlow(ImDrawList* dl, const ImVec2& at, unsigned int c, const char* s) {
    dl->AddText(ImVec2(at.x + 1.f, at.y + 1.f), 0xFF000000, s);
    dl->AddText(at, c, s);
}

static void drawBox(ImDrawList* dl, float x, float y, float w, float h, unsigned int c) {
    if (w < 4 || h < 4) return;
    const ImVec2 a(x, y), b(x + w, y + h);
    switch (g_cfg.espBoxStyle) {
        case 0: { // corner
            float len = w * 0.26f, lh = h * 0.18f;
            dl->AddLine(a, ImVec2(x + len, y), c, 2.f); dl->AddLine(a, ImVec2(x, y + lh), c, 2.f);
            dl->AddLine(ImVec2(x + w, y), ImVec2(x + w - len, y), c, 2.f);
            dl->AddLine(ImVec2(x + w, y), ImVec2(x + w, y + lh), c, 2.f);
            dl->AddLine(a + ImVec2(0, h), ImVec2(x + len, y + h), c, 2.f);
            dl->AddLine(a + ImVec2(0, h), ImVec2(x, y + h - lh), c, 2.f);
            dl->AddLine(b, ImVec2(x + w - len, y + h), c, 2.f);
            dl->AddLine(b, ImVec2(x + w, y + h - lh), c, 2.f);
            break;
        }
        case 1: // full
            dl->AddRect(a, b, c, 1.f, 0, 1.6f);
            break;
        case 2: { // glow / chams-style silhouette
            for (int i = 3; i >= 1; --i)
                dl->AddRect(ImVec2(x - i, y - i), ImVec2(x + w + i, y + h + i),
                            c & 0x18FFFFFF, 4.f, 0, (float)i);
            dl->AddRectFilled(a, b, c & 0x28FFFFFF);
            dl->AddRect(a, b, c, 2.f, 0, 1.8f);
            break;
        }
        default: { // minimal: top corners + bottom edge
            float len = w * 0.3f;
            dl->AddLine(a, ImVec2(x + len, y), c, 2.f);
            dl->AddLine(ImVec2(x + w, y), ImVec2(x + w - len, y), c, 2.f);
            dl->AddLine(ImVec2(x, y + h), ImVec2(x + w, y + h), c, 1.5f);
            break;
        }
    }
}

static ImVec2 screenOf(const PlayerInfo& p, float yOffset) {
    Vector3 pt{ p.pos.x, p.pos.y + yOffset, p.pos.z };
    Vector3 s = w2s(g.camera, pt);
    return ImVec2(s.x, (float)g.screenH - s.y);
}

static ImVec2 toIm(const Vector2& v) { return ImVec2(v.x, v.y); }

static void drawSkeleton(ImDrawList* dl, const PlayerInfo& p, unsigned int c) {
    if (!p.hasBones) return;
    auto seg = [&](int a, int b) {
        ImVec2 A = toIm(p.bonesScreen[a]), B = toIm(p.bonesScreen[b]);
        if ((A.x == 0 && A.y == 0) || (B.x == 0 && B.y == 0)) return;
        float len = sqrtf((A.x-B.x)*(A.x-B.x) + (A.y-B.y)*(A.y-B.y));
        float maxLen = fabsf(p.feetScreen.y - p.headScreen.y) * 1.6f + 40.f;
        if (len > maxLen) return; // ignore broken/out-of-range bone links
        dl->AddLine(A + ImVec2(1, 1), B + ImVec2(1, 1), 0xAA000000, 3.2f);
        dl->AddLine(A, B, c, 1.8f);
    };
    // Index order = Onetap.Targets.Bone enum:
    // Head, Chest, Pelvis, ArmLeft, ArmRight, ThighLeft, ThighRight, ShinLeft, ShinRight
    seg(0, 1); seg(1, 2);            // head -> chest -> pelvis
    seg(1, 3); seg(1, 4);            // shoulders -> arms
    seg(2, 5); seg(2, 6);            // pelvis -> thighs
    seg(5, 7); seg(6, 8);            // thighs -> shins
    if (p.hasBox) {
        dl->AddLine(toIm(p.bonesScreen[5]), toIm(p.feetScreen), c, 1.6f);
        dl->AddLine(toIm(p.bonesScreen[6]), toIm(p.feetScreen), c, 1.6f);
    }
    for (int i = 0; i < 9; i++) {
        ImVec2 q = toIm(p.bonesScreen[i]);
        if (q.x == 0 && q.y == 0) continue;
        dl->AddCircleFilled(q, 1.9f, c);
    }
}

// Approximate chams: a solid green silhouette built from the real bone points.
static void drawChams(ImDrawList* dl, const PlayerInfo& p, float w) {
    if (!p.hasBones) return;
    unsigned int solid = 0xE000FF00, soft = 0x7000FF00;
    auto limb = [&](int a, int b) {
        ImVec2 A = toIm(p.bonesScreen[a]), B = toIm(p.bonesScreen[b]);
        if ((A.x == 0 && A.y == 0) || (B.x == 0 && B.y == 0)) return;
        float len = sqrtf((A.x-B.x)*(A.x-B.x) + (A.y-B.y)*(A.y-B.y));
        if (len > w * 5.f) return;
        dl->AddLine(A, B, soft, w * 0.22f);
        dl->AddLine(A, B, solid, w * 0.13f);
    };
    limb(0, 1); limb(1, 2); limb(1, 3); limb(1, 4);
    limb(2, 5); limb(2, 6); limb(5, 7); limb(6, 8);
    for (int i = 0; i < 9; i++) {
        ImVec2 q = toIm(p.bonesScreen[i]);
        if (q.x == 0 && q.y == 0) continue;
        dl->AddCircleFilled(q, w * 0.11f, solid);
    }
}

static void render() {
    if (!g_cfg.espEnabled || !g.ready || g.players.empty()) return;
    ImDrawList* dl = ImGui::GetBackgroundDrawList();

    for (const auto& p : g.players) {
        if (p.hasBox) {
            bool boxOn = (p.headScreen.x > -100.f && p.headScreen.x < g.screenW + 100.f &&
                          p.headScreen.y > -100.f && p.headScreen.y < g.screenH + 100.f) ||
                         (p.feetScreen.x > -100.f && p.feetScreen.x < g.screenW + 100.f &&
                          p.feetScreen.y > -100.f && p.feetScreen.y < g.screenH + 100.f);
            if (!boxOn) continue;
        } else if (!p.onScreen) continue;
        if (p.local) continue;
        if (g_cfg.espMaxDist > 0 && p.dist > g_cfg.espMaxDist) continue;
        if (g_cfg.espVisibleOnly && !p.visible) continue;

        unsigned int c = pickColor(p);
        float x, y, w, h;
        if (p.hasBones) {
            // Tight box from the real projected bones, not a guessed ratio.
            float mnx = 1e9f, mny = 1e9f, mxx = -1e9f, mxy = -1e9f;
            auto add = [&](ImVec2 q) {
                if (q.x == 0 && q.y == 0) return;
                mnx = fminf(mnx, q.x); mxx = fmaxf(mxx, q.x);
                mny = fminf(mny, q.y); mxy = fmaxf(mxy, q.y);
            };
            for (int i = 0; i < 9; i++) add(toIm(p.bonesScreen[i]));
            if (p.hasBox) { add(toIm(p.headScreen)); add(toIm(p.feetScreen)); }
            if (mxx > mnx) {
                x = mnx - 4.f; y = mny - 4.f;
                w = mxx - mnx + 8.f; h = mxy - mny + 8.f;
            } else if (p.hasBox) {
                h = fabsf(p.feetScreen.y - p.headScreen.y);
                w = h * 0.40f; x = p.headScreen.x - w * 0.5f; y = p.headScreen.y;
            }
        } else if (p.hasBox) {
            float top = fminf(p.headScreen.y, p.feetScreen.y);
            float bot = fmaxf(p.headScreen.y, p.feetScreen.y);
            float cx = (p.headScreen.x + p.feetScreen.x) * 0.5f;
            h = bot - top;
            w = h * 0.40f;
            if (w < 6.f) w = 6.f;
            if (h < 10.f) h = 10.f;
            x = cx - w * 0.5f;
            y = top;
        } else {
            h = (g.screenH / (2.f * tanf(g.fov * 3.14159f / 360.f))) * (1.8f / (p.dist > 1 ? p.dist : 1));
            w = h * 0.40f;
            if (h > g.screenH * 2) h = g.screenH * 2;
            if (h < 8) h = 8;
            x = p.screen.x - w / 2; y = p.screen.y - h;
        }

        if (g_cfg.chams) drawChams(dl, p, w);
        if (g_cfg.espBox) drawBox(dl, x, y, w, h, c);
        if (g_cfg.espSkeleton) drawSkeleton(dl, p, c);

        float ty = y - 6.f;
        if (g_cfg.espHealth && p.hp > 0) {
            float pct = p.hp > 100 ? 1.f : (float)p.hp / 100.f;
            dl->AddRectFilled(ImVec2(x, ty), ImVec2(x + w, ty + 5), 0xEE101014);
            for (int i = 0; i < 10; i++) {
                if (i / 10.f >= pct) break;
                unsigned int hc = i > 6 ? 0xFF44FF66 : (i > 3 ? 0xFF66DDFF : 0xFFFF7744);
                dl->AddRectFilled(ImVec2(x + 1 + i * (w - 2) / 10, ty + 1),
                                  ImVec2(x + (i + 1) * (w - 2) / 10 - 1, ty + 4), hc);
            }
            ty -= 9.f;
        }
        if (g_cfg.espName) {
            std::string label = p.name;
            if (g_cfg.espWeapon && !p.weaponName.empty()) label += "  [" + p.weaponName + "]";
            textGlow(dl, ImVec2(x, ty - 14.f), c, label.c_str());
            ty -= 15.f;
        }
        if (g_cfg.espDistance) {
            char buf[32]; snprintf(buf, sizeof(buf), "%.0fm", p.dist);
            textGlow(dl, ImVec2(x, ty - 14.f), 0xFFEEEEEE, buf);
        }
    }
}

} // namespace esp
