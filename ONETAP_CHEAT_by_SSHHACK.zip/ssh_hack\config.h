#pragma once
#include <windows.h>

// ------------------------------------------------------------ Settings (SSH HACK)
struct Settings {
    bool showMenu = true;

    // ESP
    bool espEnabled   = true;
    bool espBox       = true;
    bool espName      = true;
    bool espHealth    = true;
    bool espDistance  = true;
    bool espWeapon    = false;
    bool espSkeleton  = false;
    bool espFilledBox = false;
    bool espVisibleOnly = false;
    float espMaxDist  = 300.f;
    int   espBoxStyle = 0; // 0=corner 0=full

    // Colors (ImGui U32 RGBA)
    unsigned int colEnemy   = 0xFF4444FF; // red
    unsigned int colTeam    = 0xFFFFCC44; // yellow
    unsigned int colLocal   = 0xFF44FF44; // green
    unsigned int colSkeleton= 0xFFFFFFFF;

    // Aimbot
    bool aimEnabled   = false;
    int  aimKey       = 0x02; // VK_RBUTTON
    bool aimToggle    = false;
    float aimFov      = 60.f;
    float aimSmooth   = 1.0f; // 1=instant
    bool aimVisible   = true;
    bool aimNearest   = true; // nearest to crosshair (else closest distance)

    // RAGE (Unity-adapted: no server tick/choke/lag compensation exists offline)
    bool rageEnabled     = true;
    bool rageSilent      = true;   // snap for one frame, then restore the view
    bool rageAutoFire    = true;   // click when the crosshair crosses a hitbox
    bool rageDoubleTap   = false;
    bool rageRefineShot  = true;
    float rageFov        = 35.f;   // degrees, angular distance from crosshair
    float rageSpeed      = 100.f;  // 0-100%, 100% = instant snap
    float rageFireDelay  = 90.f;   // ms between automatic shots
    bool antiAim         = false;
    int  antiAimYawMode  = 0;      // 0 Backward, 1 Static, 2 Spin, 3 Jitter
    int  antiAimPitchMode= 0;      // 0 Disabled, 1 Down, 2 Up, 3 Zero, 4 Random
    float antiAimYawOffset = 0.f;
    bool desync          = false;
    bool resolver        = true;
    int  resolverMode    = 1;      // 0 History, 1 Multipoint, 2 Ignore fake
    bool rageVisuals     = true;
    bool rageName        = true;
    bool rageDistance    = true;
    bool thirdPerson     = false;
    float thirdDistance  = 3.f;
    bool wallPenetration = true;   // damage is applied ignoring obstacles
    float silentDamage   = 120.f;  // damage dealt by a silent headshot
    bool flyDown         = false;  // noclip + descend while the bind is held
    int  flyKey          = 0;      // VK index, see k_vkKeys
    bool chams           = false;

    // Misc
    bool noRecoil     = false;
    bool noSpread     = false;
    float customFov   = 0.f;  // 0 = default
    bool rainbow      = false;
    bool watermark    = true;
};

static Settings g_cfg;

static inline bool keyHeld(int vk) { return (GetAsyncKeyState(vk) & 0x8000) != 0; }
