#pragma once

#include <cstdint>
#include <string>

// Предварительное объявление структуры Config. 
// Это избавит ui.h от необходимости включать config.h и вызовет циклический импорт.
struct Config;

struct MenuInfo {
    bool attached = false;
    bool offsetsLoaded = false;
    std::string offsetsError;
    uint32_t pid = 0;        // Заменили DWORD на uint32_t
    uintptr_t clientBase = 0;
    uintptr_t localPawn = 0;
    uint32_t stride = 0;
    int strideScore = 0;
    int players = 0;
    int drawn = 0;
    float fps = 0.0f;
};

void DrawMenu(Config& cfg, const MenuInfo& info);