#ifndef TOGH_CONFIG_H
#define TOGH_CONFIG_H

#include "imgui.h"

struct Config {
    bool enabled = true;
    bool menuVisible = false;

    bool teamCheck = true;
    bool drawBox = true;
    bool drawHealth = true;
    bool drawName = true;
    bool drawDistance = false;
    bool drawSnapline = false;
    bool drawSkeleton = true;
    bool spottedColor = true;

    float thickness = 1.5f;
    float maxDistance = 0.0f;   // meters, 0 = no limit
    float fontSize = 15.0f;

    // Performance: overlay refresh cap and memory scan rate.
    int targetFps = 120;
    int dataHz = 90;

    ImU32 enemyColor = IM_COL32(240, 60, 60, 235);
    ImU32 enemyHiddenColor = IM_COL32(240, 170, 60, 235);
    ImU32 teamColor = IM_COL32(90, 190, 255, 215);
    ImU32 textColor = IM_COL32(240, 240, 240, 240);
};

#endif // TOGH_CONFIG_H