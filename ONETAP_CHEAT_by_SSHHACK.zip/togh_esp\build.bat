@echo off
call "C:\Program Files\Microsoft Visual Studio\18\Professional\VC\Auxiliary\Build\vcvars64.bat" >nul 2>&1
if errorlevel 1 (echo vcvars64 failed & exit /b 1)
cd /d "%~dp0"
cl /nologo /std:c++17 /EHsc /O2 /utf-8 /MT /D_CRT_SECURE_NO_WARNINGS ^
   /I. /Iimgui /Iimgui\backends ^
   main.cpp game.cpp esp.cpp ui.cpp ^
   imgui\imgui.cpp imgui\imgui_draw.cpp imgui\imgui_tables.cpp imgui\imgui_widgets.cpp ^
   imgui\backends\imgui_impl_win32.cpp imgui\backends\imgui_impl_dx11.cpp ^
   /link /DLL /OUT:togh_onetap.dll d3d11.lib dxgi.lib d3dcompiler.lib user32.lib gdi32.lib imm32.lib kernel32.lib > build.log 2>&1
if errorlevel 1 (type build.log & exit /b 1)
echo BUILD OK: togh_onetap.dll
