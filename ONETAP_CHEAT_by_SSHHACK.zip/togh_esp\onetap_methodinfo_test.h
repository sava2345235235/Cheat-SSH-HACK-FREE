#pragma once
#include "onetap_il2cpp.h"
#include <cstdint>

// IL2CPP MethodInfo layout (x64):
// struct MethodInfo { void* methodPointer; void* invoker_method; const char* name; ... };
struct MethodInfoRaw {
    void* methodPointer;
    void* invoker_method;
    const char* name;
    void* decl_type;
    uint32_t token;
    // ...
};

static inline void* methodPtr(Il2CppMethod m) {
    return m ? ((MethodInfoRaw*)m)->methodPointer : nullptr;
}
