# togh ESP → ONETAP

Отдельная сборка togh ESP под офлайн-игру **ONETAP** (Unity 2022.3 / IL2CPP / D3D11).

Визуальная часть **не менялась**: `esp.cpp`, `esp.h`, `config.h`, `ui.h`, `ui.cpp` —
точные копии из `F:\togh\togh\src`. Переписан только источник данных: вместо чтения
памяти `cs2.exe` через `ReadProcessMemory` данные берутся прямо из IL2CPP-рантайма
ONETAP внутри инжектированной DLL.

## Что где

| Файл | Что делает |
| --- | --- |
| `esp.cpp/.h` | оригинальная отрисовка togh (бокс, HP, имя, дистанция, снаплайн, скелет) — без изменений |
| `ui.cpp/.h` | оригинальное меню togh — без изменений |
| `config.h` | оригинальные настройки/цвета — без изменений |
| `game.cpp/.h` | новый провайдер: IL2CPP → `Player[]` + матрица проекта камеры |
| `onetap_*.h` | мост к IL2CPP (классы, поля, методы Unity) |
| `main.cpp` | точ входа DLL: хук Present, ImGui, вызов `DrawEsp` / `DrawMenu` |
| `injector.exe` | инжектор (ищет процесс `ONETAP.exe`) |

## Сборка

```
build.bat
```

Результат: `togh_onetap.dll` в этой же папке.

## Запуск

1. Запустить `ONETAP.exe` и зайти в матч/тренировку.
2. Запустить `injector.exe` (или `injector.exe "F:\onetap_togh\togh_onetap.dll"`).
3. В игре:
   - **INSERT** — меню togh;
   - **F8** — вкл/выкл ESP;
   - **END** — выключить отрисовку.

Лог: `C:\Users\dwad1\AppData\Local\Temp\opencode\onetap_togh.log`

В логе есть самопроверка проекции:
```
[w2s] unity=(960.0,540.0,10.0) mine=(960.0,540.0) w=10.00 fov=60.0
```
`unity` — результат родного `Camera.WorldToScreenPoint`, `mine` — матрица, которую
использует `esp.cpp`. Значения совпадают ⇒ ESP рисуется в правильных координатах.

`[esp] players=N drawn=M` — сколько ботов собрано и сколько нарисовано.
