﻿#pragma once
// RAGE adapted to ONETAP (offline Unity FPS).
// True silent aim: the view is NEVER moved. Instead the game's own
// OnetapGame.Damage(HitRegion head, float) is invoked on the target's head
// hitbox, so the hit registers in the head while the player looks elsewhere.
#include "config.h"
#include "game.h"
#include <cmath>
#include <unordered_map>
#include <deque>
#include <string>
#include <algorithm>

namespace rage {

struct History {
    std::deque<Vector3> pts;
    Vector3 last{};
    bool haveLast = false;
    int skipped = 0;
};
static std::unordered_map<Il2CppObject*, History> g_history;

static float norm(float a) {
    while (a > 180.f) a -= 360.f;
    while (a < -180.f) a += 360.f;
    return a;
}

static DWORD g_nextTap = 0;
static int   g_tapsLeft = 0;
static DWORD g_lastShot = 0;
static DWORD g_lastLog = 0;
static float g_spin = 0.f;
static Il2CppObject* g_hvh = nullptr;
static bool  g_noclipActive = false;
static Il2CppMethod* mDamage = nullptr;
static Il2CppMethod* mFire = nullptr;
static Il2CppMethod* mToggleNoclip = nullptr;
static Il2CppMethod* mTeleport = nullptr;

static Vector3 getCamForward(Il2CppObject* cam) {
    Vector3 out{};
    if (!cam || !g.mCamGetTransform) return out;
    Il2CppObject* tr = invokeObjSafe(g.mCamGetTransform, cam, nullptr);
    if (!tr) return out;
    Il2CppClass* tc = getClass("UnityEngine.CoreModule", "UnityEngine", "Transform");
    Il2CppMethod* mf = tc ? il2cpp_class_get_method_from_name(tc, "get_forward", 0) : nullptr;
    void* mp = mf ? methodPtr(mf) : nullptr;
    if (mp) {
        typedef void (__cdecl *fn_fwd)(Vector3* ret, void* self, void* mInfo);
        ((fn_fwd)mp)(&out, tr, (void*)mf);
    }
    return out;
}

static void applyNoRecoil() {
    if (!g_cfg.noRecoil || !g.movement) return;
    Vector2 zero{};
    Il2CppField* f = il2cpp_class_get_field_from_name(il2cpp_object_get_class(g.movement), "recoil");
    if (f && g.setFieldValueFn) {
        typedef void (__cdecl *fn_set)(void*, Il2CppField*, void*);
        ((fn_set)g.setFieldValueFn)(g.movement, f, &zero);
    } else {
        *(Vector2*)((uintptr_t)g.movement + 0x88) = zero;
    }
}

static Il2CppObject* g_camTr = nullptr;
static Il2CppMethod* mSetPosInj = nullptr;
static Vector3 g_tpOrig{};
static bool g_tpSaved = false;

// Real third person: move the camera transform behind the stored eye position
// after the game has updated, so the rendered frame uses the offset camera.
static void applyThirdPersonCamera() {
    if (!g_cfg.thirdPerson || !g.camera || !g.movement) {
        if (g_tpSaved && g_camTr && mSetPosInj) {
            Vector3 p = g_tpOrig; void* a[1] = { &p };
            invokeSafe(mSetPosInj, g_camTr, a);
            g_tpSaved = false;
        }
        return;
    }
    g_camTr = invokeObjSafe(g.mCamGetTransform, g.camera, nullptr);
    if (!g_camTr) return;
    if (!mSetPosInj) {
        Il2CppClass* tc = getClass("UnityEngine.CoreModule", "UnityEngine", "Transform");
        if (tc) mSetPosInj = il2cpp_class_get_method_from_name(tc, "set_position_Injected", 1);
    }
    if (!mSetPosInj) return;
    if (!g_tpSaved) { g_tpOrig = getCamPos(g.camera); g_tpSaved = true; }
    Vector3 f = getCamForward(g.camera);
    float d = std::clamp(g_cfg.thirdDistance, 1.5f, 8.f);
    Vector3 p{ g_tpOrig.x - f.x * d, g_tpOrig.y - f.y * d + 0.35f, g_tpOrig.z - f.z * d };
    void* args[1] = { &p };
    invokeSafe(mSetPosInj, g_camTr, args);
}

static void click(bool down) {
    mouse_event(down ? MOUSEEVENTF_LEFTDOWN : MOUSEEVENTF_LEFTUP, 0, 0, 0, 0);
}
static void shoot() { click(true); click(false); }

// HvhSettings.thirdPerson (0x68) / thirdDistance (0x6C) via OnetapGame.hvh (0x7A0).
// The game has a COMPLETE native rage system (HvhSettings + HvhUpdate):
// rage / silent / autoFire / resolver / removeSpread / removeRecoil / chams.
// Writing those fields is far more reliable than emulating shots externally.
// HvhSettings field offsets are verified from dump.cs.
static void applyHvhSettings() {
    if (!g.gameObj) return;
    g_hvh = getFieldObj(g.gameObj, "hvh", 0x7A0);
    if (!g_hvh) return;
    uintptr_t p = (uintptr_t)g_hvh;
    auto B = [&](uintptr_t o, bool v) { *(bool*)(p + o) = v; };
    auto I = [&](uintptr_t o, int v)  { *(int*)(p + o) = v; };
    auto F = [&](uintptr_t o, float v){ *(float*)(p + o) = v; };
    auto C = [&](uintptr_t o, float r, float g_, float b, float a) {
        float* c = (float*)(p + o); c[0]=r; c[1]=g_; c[2]=b; c[3]=a;
    };

    B(0x10, g_cfg.rageEnabled);          // rage
    B(0x11, g_cfg.rageSilent);           // silent aim — native, view never moves
    B(0x12, false);                      // manual fire only (auto-fire was unstable)
    B(0x15, g_cfg.resolver);             // resolver (enemy anti-aim)
    B(0x16, true);                       // remove spread
    B(0x17, g_cfg.noRecoil);             // remove recoil
    I(0x18, 0);                          // hitbox: 0 = Head
    F(0x1C, g_cfg.rageFov);              // aim FOV
    F(0x20, 100.f);                      // hit chance
    F(0x24, 0.f);                        // min damage
    B(0x28, g_cfg.antiAim);              // anti-aim
    I(0x2C, g_cfg.antiAimPitchMode);     // pitch mode
    I(0x30, g_cfg.antiAimYawMode);       // yaw mode
    F(0x34, g_cfg.antiAimYawOffset);     // yaw offset

    // Native chams including models hidden behind walls.
    B(0x46, g_cfg.chams);                // chams
    B(0x47, g_cfg.chams);                // chamsHidden — through walls
    C(0x48, 0.f, 1.f, 0.f, 1.f);         // visible colour: green
    C(0x58, 0.f, 0.55f, 1.f, 1.f);       // hidden colour: blue (through walls)

    B(0x40, false); B(0x41, false); B(0x42, false);
    B(0x43, false); B(0x44, false); B(0x45, false); // our ImGui ESP handles visuals
}

static void applyThirdPerson() {
    if (!g.gameObj) return;
    g_hvh = getFieldObj(g.gameObj, "hvh", 0x7A0);
    if (!g_hvh) return;
    Il2CppClass* c = il2cpp_object_get_class(g_hvh);
    Il2CppField* fOn = il2cpp_class_get_field_from_name(c, "thirdPerson");
    Il2CppField* fDist = il2cpp_class_get_field_from_name(c, "thirdDistance");
    bool on = g_cfg.thirdPerson;
    float dist = std::clamp(g_cfg.thirdDistance, 1.5f, 8.f);
    if (g.setFieldValueFn) {
        typedef void (__cdecl *fn_set)(void*, Il2CppField*, void*);
        if (fOn)   ((fn_set)g.setFieldValueFn)(g_hvh, fOn, &on);
        if (fDist) ((fn_set)g.setFieldValueFn)(g_hvh, fDist, &dist);
    } else {
        *(bool*)((uintptr_t)g_hvh + 0x68) = on;
        *(float*)((uintptr_t)g_hvh + 0x6C) = dist;
    }
}

// Fly down: toggle noclip on key press, teleport the player downwards while held.
static void applyFlyDown(bool justPressed, bool released) {
    if (!g_cfg.flyDown || !g.movement) return;
    if (!mToggleNoclip) {
        Il2CppClass* mc = il2cpp_object_get_class(g.movement);
        mToggleNoclip = il2cpp_class_get_method_from_name(mc, "ToggleNoclip", 0);
        mTeleport = il2cpp_class_get_method_from_name(mc, "Teleport", 3);
    }
    if (justPressed && mToggleNoclip && !g_noclipActive) {
        il2cpp_runtime_invoke(mToggleNoclip, g.movement, nullptr, nullptr);
        g_noclipActive = true;
    }
    bool held = keyHeld(g_cfg.flyKey);
    if (!held && released && mToggleNoclip && g_noclipActive) {
        il2cpp_runtime_invoke(mToggleNoclip, g.movement, nullptr, nullptr);
        g_noclipActive = false;
        return;
    }
    if (!held || !mTeleport) return;
    Vector3 p = getCamPos(g.camera);
    p.y -= 0.28f;
    float angle = getFieldFloat(g.movement, "yaw", off::MovYaw);
    uint8_t keep = 1;
    void* args[3] = { &p, &angle, &keep };
    invokeSafe(mTeleport, g.movement, args);
}

static Vector3 resolvePoint(PlayerInfo& p) {
    Vector3 head{ p.pos.x, p.pos.y + off::BotEye, p.pos.z };
    History& h = g_history[p.obj];
    Vector3 aim = head;
    if (!h.haveLast) { h.last = p.pos; h.haveLast = true; }
    float jump = sqrtf(powf(p.pos.x - h.last.x, 2) + powf(p.pos.y - h.last.y, 2) + powf(p.pos.z - h.last.z, 2));
    if (g_cfg.resolverMode == 2 && jump > 2.5f && h.skipped < 3) {
        h.skipped++;
        aim = { h.last.x, h.last.y + off::BotEye, h.last.z };
    } else {
        h.skipped = 0;
        h.pts.push_back(p.pos);
        if (h.pts.size() > 6) h.pts.pop_front();
        h.last = p.pos;
        if (g_cfg.resolverMode == 0 && h.pts.size() >= 2) {
            Vector3 avg{};
            for (const auto& q : h.pts) { avg.x += q.x; avg.y += q.y; avg.z += q.z; }
            float n = (float)h.pts.size();
            aim = { avg.x / n, avg.y / n + off::BotEye, avg.z / n };
        }
    }
    return aim;
}

// Silent aim without touching the camera: feed the game's own shot-direction
// field before the normal mouse click is processed. The view never rotates.
static void setShotDirection(PlayerInfo& p) {
    if (!g.gameObj) return;
    Vector3 eye = g.local.pos;
    Vector3 aim{ p.pos.x, p.pos.y + off::BotEye, p.pos.z };
    Vector3 d{ aim.x - eye.x, aim.y - eye.y, aim.z - eye.z };
    float len = sqrtf(d.x*d.x + d.y*d.y + d.z*d.z);
    if (len < 0.001f) return;
    d.x /= len; d.y /= len; d.z /= len;
    Il2CppField* f = il2cpp_class_get_field_from_name(il2cpp_object_get_class(g.gameObj), "lastShotDirection");
    if (f && g.setFieldValueFn) {
        typedef void (__cdecl *fn_set)(void*, Il2CppField*, void*);
        ((fn_set)g.setFieldValueFn)(g.gameObj, f, &d);
    } else {
        *(Vector3*)((uintptr_t)g.gameObj + 0x5CC) = d;
    }
}

static void run() {
    if (!g.ready) return;
    applyThirdPerson();
    applyThirdPersonCamera();
    applyNoRecoil();
    applyHvhSettings();
    // With rage enabled the game's own HvH loop handles aim, silent fire,
    // resolver and anti-aim. Our external emulation would only interfere.
    if (g_cfg.rageEnabled) return;

    static bool prevFly = false;
    bool flyNow = g_cfg.flyDown && keyHeld(g_cfg.flyKey);
    applyFlyDown(flyNow && !prevFly, !flyNow && prevFly);
    prevFly = flyNow;

    if (!g.local.obj || !g.movement || g.local.hp <= 0) return;
    DWORD now = GetTickCount();
    bool aimHeld = keyHeld(g_cfg.aimKey);

    // "Shoot anywhere, hit the closest enemy": on every left-click edge,
    // redirect the shot to the nearest live bot without moving the view.
    static bool prevLmb = false;
    bool lmb = keyHeld(VK_LBUTTON);
    if (g_cfg.rageEnabled && lmb && !prevLmb) {
        PlayerInfo* nearest = nullptr;
        float bd = 1e9f;
        for (auto& p : g.players) {
            if (p.local || !p.alive || !p.hasBox) continue;
            if (p.dist < bd) { bd = p.dist; nearest = &p; }
        }
        if (nearest) setShotDirection(*nearest);
    }
    prevLmb = lmb;

    if (g_tapsLeft > 0 && now >= g_nextTap) { shoot(); --g_tapsLeft; }

    PlayerInfo* target = nullptr;
    float bestAng = g_cfg.rageFov;
    float wantYaw = 0.f, wantPitch = 0.f;
    if (g_cfg.rageEnabled && aimHeld) {
        float curYaw = getFieldFloat(g.movement, "yaw", off::MovYaw);
        float curPitch = getFieldFloat(g.movement, "pitch", off::MovPitch);
        Vector3 eye = g.local.pos;
        for (auto& p : g.players) {
            if (p.local || !p.alive || !p.hasBox) continue;
            Vector3 aim = g_cfg.resolver ? resolvePoint(p)
                                         : Vector3{ p.pos.x, p.pos.y + off::BotEye, p.pos.z };
            float dx = aim.x - eye.x, dy = aim.y - eye.y, dz = aim.z - eye.z;
            float horiz = sqrtf(dx*dx + dz*dz);
            if (horiz < 0.05f) continue;
            float ty = atan2f(dx, dz) * 57.2957795f;
            float tp = -atan2f(dy, horiz) * 57.2957795f;
            float score = fabsf(norm(ty - curYaw)) + fabsf(norm(tp - curPitch));
            if (score < bestAng) { bestAng = score; target = &p; wantYaw = ty; wantPitch = tp; }
        }

        if (target) {
            if (g_cfg.rageSilent) {
                // true silent aim: do NOT touch yaw/pitch at all
            } else {
                float k = g_cfg.rageSpeed / 100.f;
                float ny = norm(wantYaw - curYaw) * k;
                float np = norm(wantPitch - curPitch) * k;
                setFieldFloat(g.movement, g.fldYaw,   off::MovYaw,   curYaw + ny);
                setFieldFloat(g.movement, g.fldPitch, off::MovPitch, std::clamp(curPitch + np, -89.f, 89.f));
            }

            bool canShoot = g_cfg.wallPenetration || bestAng < 5.f;
            if (g_cfg.rageAutoFire && canShoot && now - g_lastShot >= (DWORD)g_cfg.rageFireDelay) {
                g_lastShot = now;
                if (g_cfg.rageSilent) setShotDirection(*target);
                shoot();
                if (g_cfg.rageDoubleTap) { g_tapsLeft = 1; g_nextTap = now + 45; }
            }
            if (now - g_lastLog > 900) {
                g_lastLog = now;
                logf2("[rage] %s ang=%.1f silent=%d pen=%d dmg=%.0f",
                      target->name.c_str(), bestAng, (int)g_cfg.rageSilent,
                      (int)g_cfg.wallPenetration, g_cfg.silentDamage);
            }
            return;
        }
    }

    if (!g_cfg.antiAim) return;
    float yaw = getFieldFloat(g.movement, "yaw", off::MovYaw);
    float pitch = getFieldFloat(g.movement, "pitch", off::MovPitch);
    float addYaw = g_cfg.antiAimYawOffset;
    switch (g_cfg.antiAimYawMode) {
        case 0: addYaw += 180.f; break;
        case 1: break;
        case 2: g_spin += 2.5f; addYaw += g_spin; break;
        case 3: addYaw += (now & 256) ? 42.f : -42.f; break;
        default: break;
    }
    if (g_cfg.desync) addYaw += (now & 128) ? 25.f : -25.f;
    float aaPitch = pitch;
    switch (g_cfg.antiAimPitchMode) {
        case 1: aaPitch = -40.f; break;
        case 2: aaPitch = 40.f; break;
        case 3: aaPitch = 0.f; break;
        case 4: aaPitch = sinf(now * 0.004f) * 35.f; break;
        default: break;
    }
    setFieldFloat(g.movement, g.fldYaw, off::MovYaw, yaw + addYaw);
    setFieldFloat(g.movement, g.fldPitch, off::MovPitch, aaPitch);
}

} // namespace rage



