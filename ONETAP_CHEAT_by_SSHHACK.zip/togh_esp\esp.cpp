#include "esp.h"

#include <algorithm>
#include <cfloat>
#include <cmath>
#include <cstdio>

namespace {

const ImU32 kShadow = IM_COL32(0, 0, 0, 160);
const ImU32 kHealthBack = IM_COL32(0, 0, 0, 170);

ImU32 HealthColor(int health) {
    const float t = std::clamp(health / 100.0f, 0.0f, 1.0f);
    const float r = 235.0f + (90.0f - 235.0f) * t;
    const float g = 70.0f + (215.0f - 70.0f) * t;
    const float b = 70.0f + (95.0f - 70.0f) * t;
    return IM_COL32(static_cast<int>(r), static_cast<int>(g), static_cast<int>(b), 235);
}

void TextShadow(ImDrawList* drawList, ImFont* font, float size, const ImVec2& pos, ImU32 color, const char* text) {
    drawList->AddText(font, size, ImVec2(pos.x + 1.0f, pos.y + 1.0f), kShadow, text);
    drawList->AddText(font, size, pos, color, text);
}

}  // namespace

bool WorldToScreen(const float view[16], const Vec3& world, ImVec2& out, int width, int height) {
    const float w = view[12] * world.x + view[13] * world.y + view[14] * world.z + view[15];
    if (w < 0.01f) {
        return false;
    }
    const float x = view[0] * world.x + view[1] * world.y + view[2] * world.z + view[3];
    const float y = view[4] * world.x + view[5] * world.y + view[6] * world.z + view[7];

    const float ndcX = x / w;
    const float ndcY = y / w;

    out.x = (static_cast<float>(width) * 0.5f) * (ndcX + 1.0f);
    out.y = (static_cast<float>(height) * 0.5f) * (1.0f - ndcY);
    return true;
}

void DrawEsp(ImDrawList* drawList, const std::vector<Player>& players, const float view[16],
             int width, int height, const Config& cfg, ImFont* font, EspStats& stats) {
    stats.total = static_cast<int>(players.size());
    stats.drawn = 0;

    for (const Player& player : players) {
        if (cfg.teamCheck && player.teammate) {
            continue;
        }
        if (cfg.maxDistance > 0.0f && player.distance > cfg.maxDistance) {
            continue;
        }

        ImVec2 corners[8];
        int visible = 0;
        float minX = FLT_MAX;
        float minY = FLT_MAX;
        float maxX = -FLT_MAX;
        float maxY = -FLT_MAX;

        for (int i = 0; i < 8; ++i) {
            Vec3 point{
                player.origin.x + ((i & 1) ? player.maxs.x : player.mins.x),
                player.origin.y + ((i & 2) ? player.maxs.y : player.mins.y),
                player.origin.z + ((i & 4) ? player.maxs.z : player.mins.z),
            };
            ImVec2 screen;
            if (!WorldToScreen(view, point, screen, width, height)) {
                continue;
            }
            corners[visible++] = screen;
            minX = std::min(minX, screen.x);
            minY = std::min(minY, screen.y);
            maxX = std::max(maxX, screen.x);
            maxY = std::max(maxY, screen.y);
        }

        if (visible < 4) {
            continue;
        }

        const float boxWidth = maxX - minX;
        const float boxHeight = maxY - minY;
        if (boxWidth < 2.0f || boxHeight < 8.0f) {
            continue;
        }
        if (minX > static_cast<float>(width) || maxX < 0.0f ||
            minY > static_cast<float>(height) || maxY < 0.0f) {
            continue;
        }

        ImU32 color = cfg.enemyColor;
        if (player.teammate) {
            color = cfg.teamColor;
        } else if (cfg.spottedColor && !player.spotted) {
            color = cfg.enemyHiddenColor;
        }

        ++stats.drawn;

        const float thickness = std::max(0.5f, cfg.thickness);

        if (cfg.drawSnapline && !player.teammate) {
            const ImU32 lineColor = (color & 0x00FFFFFF) | (110u << 24);
            drawList->AddLine(ImVec2(static_cast<float>(width) * 0.5f, static_cast<float>(height)),
                              ImVec2((minX + maxX) * 0.5f, maxY), lineColor, thickness);
        }

        if (cfg.drawBox) {
            const ImVec2 topLeft(minX - 1.0f, minY - 1.0f);
            const ImVec2 bottomRight(maxX + 1.0f, maxY + 1.0f);
            drawList->AddRect(topLeft, bottomRight, kShadow, 0.0f, 0, thickness + 2.0f);
            drawList->AddRect(topLeft, bottomRight, color, 0.0f, 0, thickness);
        }

        if (cfg.drawSkeleton && player.hasBones) {
            ImVec2 boneScreens[16];
            bool boneValid[16] = {};
            for (int i = 0; i < 16; ++i) {
                boneValid[i] = WorldToScreen(view, player.bones[i], boneScreens[i], width, height);
            }

            // Bone array mapping:
            // 0: Head, 1: Neck, 2: Spine, 3: Pelvis
            // 4: L-Arm, 5: L-Elbow, 6: L-Hand
            // 7: R-Arm, 8: R-Elbow, 9: R-Hand
            // 10: L-Thigh, 11: L-Knee, 12: L-Foot
            // 13: R-Thigh, 14: R-Knee, 15: R-Foot
            const int conns[15][2] = {
                {0, 1}, {1, 2}, {2, 3},      
                {2, 4}, {4, 5}, {5, 6},      
                {2, 7}, {7, 8}, {8, 9},      
                {3, 10}, {10, 11}, {11, 12}, 
                {3, 13}, {13, 14}, {14, 15}  
            };

            for (const auto& conn : conns) {
                if (boneValid[conn[0]] && boneValid[conn[1]]) {
                    drawList->AddLine(boneScreens[conn[0]], boneScreens[conn[1]], color, thickness);
                }
            }
        }

        if (cfg.drawHealth) {
            const float barHeight = std::max(20.0f, boxHeight);
            const float barX = minX - 6.0f;
            const float filled = barHeight * std::clamp(player.health / 100.0f, 0.0f, 1.0f);
            drawList->AddRectFilled(ImVec2(barX - 1.0f, minY - 1.0f),
                                    ImVec2(barX + 4.0f, minY + barHeight + 1.0f), kHealthBack);
            drawList->AddRectFilled(ImVec2(barX, minY + barHeight - filled),
                                    ImVec2(barX + 3.0f, minY + barHeight), HealthColor(player.health));
        }

        const float textSize = std::max(8.0f, cfg.fontSize);

        if (cfg.drawName) {
            const ImVec2 textWidth = font->CalcTextSizeA(textSize, FLT_MAX, 0.0f, player.name);
            const ImVec2 pos((minX + maxX) * 0.5f - textWidth.x * 0.5f, minY - textSize - 4.0f);
            TextShadow(drawList, font, textSize, pos, cfg.textColor, player.name);
        }

        if (cfg.drawDistance) {
            char buffer[32];
            std::snprintf(buffer, sizeof(buffer), "%.0f m", player.distance);
            const ImVec2 textWidth = font->CalcTextSizeA(textSize, FLT_MAX, 0.0f, buffer);
            const ImVec2 pos((minX + maxX) * 0.5f - textWidth.x * 0.5f, maxY + 3.0f);
            TextShadow(drawList, font, textSize, pos, cfg.textColor, buffer);
        }
    }
}