﻿// SSH HACK for ONETAP — IL2CPP ESP + Aimbot + ImGui menu
#include "config.h"
#include "game.h"
#include "esp_render.h"
#include "aimbot.h"
#include "rage.h"
#include "ssh_menu.h"
#include "methodinfo_test.h"

#include <d3d11.h>
#include <imgui/imgui.h>
#include <imgui/backends/imgui_impl_win32.h>
#include <imgui/backends/imgui_impl_dx11.h>
#include <cstdio>
#include <exception>

// ------------------------------------------------------------ globals
static bool      g_inited = false;
static ID3D11Device* g_dev = nullptr;
static ID3D11DeviceContext* g_dc = nullptr;
static ID3D11RenderTargetView* g_rtv = nullptr;
static UINT      g_resW = 1920, g_resH = 1080;
static HWND      g_hwnd = nullptr;
static DWORD     g_dataTimer = 0;
static bool      g_gameReady = false;
static FILE*     g_log = nullptr;

static void logf(const char* fmt, ...) {
    if (!g_log) return;
    va_list ap; va_start(ap, fmt);
    vfprintf(g_log, fmt, ap); fputc('\n', g_log); fflush(g_log);
    va_end(ap);
}
void logf2(const char* fmt, ...) {
    if (!g_log) return;
    va_list ap; va_start(ap, fmt);
    vfprintf(g_log, fmt, ap); fputc('\n', g_log); fflush(g_log);
    va_end(ap);
}

// ------------------------------------------------------------ WndProc
typedef LRESULT(CALLBACK* t_WndProc)(HWND, UINT, WPARAM, LPARAM);
static t_WndProc o_WndProc = nullptr;
extern IMGUI_IMPL_API LRESULT ImGui_ImplWin32_WndProcHandler(HWND, UINT, WPARAM, LPARAM);

static void collectData() {
    if (!g_gameReady) return;
    // The Present thread must be attached to the IL2CPP VM before any
    // runtime_invoke/field call. Missing this corrupts GC state and crashes.
    if (il2cpp_thread_attach && il2cpp_domain_get()) il2cpp_thread_attach(il2cpp_domain_get());
    g.screenW = (int)g_resW; g.screenH = (int)g_resH;
    refreshCamera(g_cfg.customFov);
    refreshPlayers(true);
    projectPlayers();
}

static LRESULT CALLBACK hk_WndProc(HWND h, UINT m, WPARAM w, LPARAM l) {
    if (g_inited && ImGui_ImplWin32_WndProcHandler(h, m, w, l)) return 1;
    if (!o_WndProc) return DefWindowProcA(h, m, w, l);
    return CallWindowProcA(o_WndProc, h, m, w, l);
}

// ------------------------------------------------------------ Present hook
typedef HRESULT(WINAPI* t_Present)(IDXGISwapChain*, UINT, UINT);
typedef HRESULT(WINAPI* t_Resize)(IDXGISwapChain*, UINT, UINT, DXGI_FORMAT, UINT);
static t_Present o_Present = nullptr;
static t_Resize o_Resize = nullptr;

static bool initImGui(IDXGISwapChain* sc) {
    if (g_inited) return true;
    DXGI_SWAP_CHAIN_DESC sd{};
    if (FAILED(sc->GetDesc(&sd))) return false;
    g_resW = sd.BufferDesc.Width ? sd.BufferDesc.Width : 1920;
    g_resH = sd.BufferDesc.Height ? sd.BufferDesc.Height : 1080;
    if (FAILED(sc->GetDevice(__uuidof(ID3D11Device), (void**)&g_dev))) return false;
    g_dev->GetImmediateContext(&g_dc);
    if (!g_dc) return false;

    ImGui::CreateContext();
    ImGuiIO& io = ImGui::GetIO();
    io.IniFilename = nullptr;
    // NL menu fonts must be added before the first NewFrame builds the atlas.
    sshmenu::loadFonts();
    io.DisplaySize = ImVec2((float)g_resW, (float)g_resH);

    g_hwnd = sd.OutputWindow;
    ImGui_ImplWin32_Init(g_hwnd);
    ImGui_ImplDX11_Init(g_dev, g_dc);
    ImGui::StyleColorsDark();

    if (g_hwnd && !o_WndProc)
        o_WndProc = (t_WndProc)SetWindowLongPtrA(g_hwnd, GWLP_WNDPROC, (LONG_PTR)hk_WndProc);
    g_inited = true;
    if (g_hwnd && !g_dataTimer) g_dataTimer = SetTimer(g_hwnd, 1, 16, nullptr);
    logf("[imgui] init res=%ux%u hwnd=%p", g_resW, g_resH, (void*)g_hwnd);
    return true;
}

static void shutdownImGui() {
    bool was = g_inited; g_inited = false;
    if (g_hwnd && o_WndProc) {
        if (g_dataTimer) { KillTimer(g_hwnd, g_dataTimer); g_dataTimer = 0; }
        SetWindowLongPtrA(g_hwnd, GWLP_WNDPROC, (LONG_PTR)o_WndProc);
        o_WndProc = nullptr;
    }
    if (was) {
        sshmenu::shutdown();
        ImGui_ImplDX11_Shutdown();
        ImGui_ImplWin32_Shutdown();
        ImGui::DestroyContext();
    }
    if (g_rtv) { g_rtv->Release(); g_rtv = nullptr; }
    if (g_dc) { g_dc->Release(); g_dc = nullptr; }
    if (g_dev) { g_dev->Release(); g_dev = nullptr; }
}

static ID3D11RenderTargetView* getRtv(IDXGISwapChain* sc) {
    if (g_rtv) return g_rtv;
    ID3D11Texture2D* bb = nullptr;
    if (SUCCEEDED(sc->GetBuffer(0, __uuidof(ID3D11Texture2D), (void**)&bb)) && bb) {
        g_dev->CreateRenderTargetView(bb, nullptr, &g_rtv);
        bb->Release();
    }
    return g_rtv;
}

static void frame(IDXGISwapChain* sc) {
    if (!initImGui(sc)) return;

    // hotkey: INSERT
    static bool prevIns = false;
    bool ins = keyHeld(VK_INSERT);
    if (ins && !prevIns) g_cfg.showMenu = !g_cfg.showMenu;
    prevIns = ins;

    // collect IL2CPP data every frame (Present thread is attached via il2cpp_thread_attach)
    if (g_gameReady) { try { collectData(); } catch (...) { logf("[EXC] data"); } }

    // init IL2CPP once module is loaded
    if (!g_gameReady) {
        static DWORD lastTry = 0;
        DWORD now = GetTickCount();
        if (now - lastTry > 1000) {
            lastTry = now;
            HMODULE ga = GetModuleHandleA("GameAssembly.dll");
            logf("[il2cpp] try game=%p apiLoaded=%d", (void*)ga, (int)(loadIl2Cpp != nullptr));
            if (ga) {
                if (!loadIl2Cpp(ga)) {
                    logf("[il2cpp] loadIl2Cpp FAILED");
                } else if (initGame(ga, (int)g_resW, (int)g_resH)) {
                    g_gameReady = true;
                    logf("[il2cpp] READY clsCam=%p w2sInj=%p camMain=%p", (void*)g.clsCamera, (void*)g.mCamW2SInj, (void*)g.mCamMain);
                } else {
                    logf("[il2cpp] initGame FAILED clsCam=%p clsPlayer=%p dom=%p",
                         (void*)g.clsCamera, (void*)g.clsPlayer, (void*)il2cpp_domain_get());
                }
            }
        }
    }

    ImGui_ImplDX11_NewFrame();
    ImGui_ImplWin32_NewFrame();
    ImGui::NewFrame();

    try { aim::run(); } catch (...) { logf("[EXC] aim"); }
    try { rage::run(); } catch (...) { logf("[EXC] rage"); }
    try { esp::render(); } catch (...) { logf("[EXC] esp"); }
    try { sshmenu::render(); } catch (...) { logf("[EXC] menu"); }

    static DWORD lastLog = 0;
    if (g_gameReady && GetTickCount() - lastLog > 3000) {
        lastLog = GetTickCount();
        logf("[frame] cam=%p players=%zu fov=%.1f local=%s hp=%d",
             (void*)g.camera, g.players.size(), g.fov,
             g.local.name.c_str(), g.local.hp);
    }

    ImGui::Render();
    ID3D11RenderTargetView* rtv = getRtv(sc);
    if (rtv) {
        g_dc->OMSetRenderTargets(1, &rtv, nullptr);
        ImGui_ImplDX11_RenderDrawData(ImGui::GetDrawData());
    }
}

static HRESULT WINAPI hk_Present(IDXGISwapChain* sc, UINT sync, UINT flags) {
    try { frame(sc); }
    catch (const std::exception& e) { logf("[EXC] frame std: %s", e.what()); }
    catch (...) { logf("[EXC] frame unknown"); }
    return o_Present ? o_Present(sc, sync, flags) : E_FAIL;
}
static HRESULT WINAPI hk_Resize(IDXGISwapChain* sc, UINT w, UINT h, DXGI_FORMAT f, UINT s) {
    shutdownImGui();
    return o_Resize ? o_Resize(sc, w, h, f, s) : E_FAIL;
}

static void* vmt(IDXGISwapChain* sc, int idx) { return (*(void***)sc)[idx]; }

static void installThreadBody();
static DWORD WINAPI InstallThread(LPVOID) {
    try { installThreadBody(); }
    catch (const std::exception& e) { logf("[EXC] install std: %s", e.what()); }
    catch (...) { logf("[EXC] install unknown"); }
    return 0;
}
static void installThreadBody() {
    Sleep(2000); // let DllMain/loader lock finish before using CRT
    g_log = fopen("C:\\Users\\dwad1\\AppData\\Local\\Temp\\opencode\\onetap_ssh\\ssh.log", "w");
    logf("[install] thread started");
    for (int i = 0; i < 120; i++) {
        if (GetModuleHandleA("GameAssembly.dll") && GetModuleHandleA("d3d11.dll")) {
            logf("[install] modules ready after %d00 ms", i+1);
            Sleep(3000);
            break;
        }
        Sleep(1000);
    }
    // dummy swapchain to locate Present by vtable index
    IDXGISwapChain* dummy = nullptr; ID3D11Device* dev = nullptr; ID3D11DeviceContext* ctx = nullptr;
    D3D_FEATURE_LEVEL fl; DXGI_SWAP_CHAIN_DESC sd{};
    sd.BufferCount = 1; sd.BufferDesc.Width = 1; sd.BufferDesc.Height = 1;
    sd.BufferDesc.Format = DXGI_FORMAT_R8G8B8A8_UNORM; sd.BufferUsage = DXGI_USAGE_RENDER_TARGET_OUTPUT;
    sd.OutputWindow = GetDesktopWindow(); sd.SampleDesc.Count = 1; sd.Windowed = TRUE;
    IDXGIFactory* factory = nullptr;
    CreateDXGIFactory(__uuidof(IDXGIFactory), (void**)&factory);
    D3D11CreateDeviceAndSwapChain(nullptr, D3D_DRIVER_TYPE_HARDWARE, nullptr, 0, nullptr, 0,
        D3D11_SDK_VERSION, &sd, &dummy, &dev, &fl, &ctx);

    // VMT patch: the game swapchain and our dummy share the same dxgi.dll vtable
    if (!dummy) {
        logf("[install] no dummy swapchain, hook failed");
        if (dev) dev->Release();
        if (ctx) ctx->Release();
        if (factory) factory->Release();
        return;
    }
    void** vt = *(void***)dummy;
    DWORD old = 0;
    VirtualProtect(&vt[8], sizeof(void*), PAGE_READWRITE, &old);
    o_Present = (t_Present)vt[8];
    vt[8] = (void*)hk_Present;
    VirtualProtect(&vt[8], sizeof(void*), old, &old);

    VirtualProtect(&vt[13], sizeof(void*), PAGE_READWRITE, &old);
    o_Resize = (t_Resize)vt[13];
    vt[13] = (void*)hk_Resize;
    VirtualProtect(&vt[13], sizeof(void*), old, &old);

    logf("[install] Present hooked orig=%p", (void*)o_Present);

    if (dev) dev->Release();
    if (ctx) ctx->Release();
    if (dummy) dummy->Release();
    if (factory) factory->Release();
    logf("[install] thread finished");
}

BOOL APIENTRY DllMain(HMODULE h, DWORD reason, LPVOID) {
    if (reason == DLL_PROCESS_ATTACH) {
        DisableThreadLibraryCalls(h);
        CreateThread(nullptr, 0, InstallThread, nullptr, 0, nullptr);
    }
    return TRUE;
}






