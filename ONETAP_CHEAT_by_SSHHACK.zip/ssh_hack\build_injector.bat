@echo off
call "C:\Program Files\Microsoft Visual Studio\18\Professional\VC\Auxiliary\Build\vcvars64.bat" >nul 2>&1
if errorlevel 1 (echo vcvars64 failed & exit /b 1)
cd /d "%~dp0"
cl /nologo /utf-8 /O2 /EHsc injector.cpp /link /OUT:injector.exe kernel32.lib > build_injector.log 2>&1
if errorlevel 1 (type build_injector.log & exit /b 1)
echo BUILD OK: injector.exe
