﻿#pragma once
#include "il2cpp.h"
#include "methodinfo_test.h"
#include <vector>
#include <string>
#include <cmath>
#include <algorithm>

// Offsets verified against dump.cs (Il2CppDumper v29, IL2CPP v31 x64).
// Il2CppDumper offsets are absolute from the start of the managed object,
// i.e. obj+0x10 is the first instance field (klass @0x0, monitor @0x8).
namespace off {
    constexpr uintptr_t GameTargets   = 0x458; // OnetapGame.targets   -> Onetap.Targets
    constexpr uintptr_t GameMovement  = 0x450; // OnetapGame.movement  -> OnetapMovement
    constexpr uintptr_t GameWorldCam  = 0x4B0; // OnetapGame.worldCamera
    constexpr uintptr_t GameViewCam   = 0x4B8;
    constexpr uintptr_t GameHealth    = 0x504; // OnetapGame.health
    constexpr uintptr_t GameSpawnYaw  = 0x584;
    constexpr uintptr_t TargetsList   = 0xA8;  // Targets.targets -> List<Target>
    constexpr uintptr_t TargetSpawn   = 0x20;
    constexpr uintptr_t TargetModel   = 0x30;  // Transform
    constexpr uintptr_t TargetHealth  = 0x50;
    constexpr uintptr_t TargetEnemy   = 0x69;
    constexpr uintptr_t TargetActive  = 0x6C;
    constexpr uintptr_t MovEye        = 0x38;  // OnetapMovement.eye (Camera)
    constexpr uintptr_t MovYaw        = 0x58;  // OnetapMovement.yaw
    constexpr uintptr_t MovPitch      = 0x5C;  // OnetapMovement.pitch
    constexpr float     BotEye        = 1.54f; // Targets.BotEye
    constexpr float     StandEye      = 1.62f; // OnetapMovement.StandEye
    constexpr uintptr_t Il2CppArrayData = 0x20; // element data in Il2CppArray (x64)
}

struct PlayerInfo {
    Il2CppObject* obj = nullptr;
    Vector3 pos{};
    float yaw = 0, pitch = 0;
    int hp = 0, life = 0, kills = 0, deaths = 0, weapon = 0;
    bool alive = false, inMatch = false, local = false;
    std::string name;
    std::string weaponName;
    Vector2 screen{};
    Vector2 headScreen{}, feetScreen{};   // exact projected head/feet
    Vector2 bonesScreen[9]{};              // real BotAnimator bone positions, projected
    bool hasBox = false;                   // headScreen/feetScreen valid
    bool hasBones = false;                 // bonesScreen[] valid
    float dist = 0;
    bool onScreen = false;
    bool visible = true;
};

struct GameState {
    HMODULE game = nullptr;
    Il2CppClass* clsCamera = nullptr;
    Il2CppClass* clsPlayer = nullptr;
    Il2CppField* fldAll = nullptr;

    Il2CppMethod* mCamMain = nullptr;
    Il2CppMethod* mCamW2S = nullptr;
    Il2CppMethod* mCamW2SInj = nullptr;
    Il2CppMethod* mCamGetFov = nullptr;
    Il2CppMethod* mCamSetFov = nullptr;
    Il2CppMethod* mCamGetTransform = nullptr;

    Il2CppMethod* mPlayerLocal = nullptr;
    Il2CppMethod* mPlayerPos = nullptr;
    Il2CppMethod* mPlayerYaw = nullptr;
    Il2CppMethod* mPlayerPitch = nullptr;
    Il2CppMethod* mPlayerSetYaw = nullptr;
    Il2CppMethod* mPlayerSetPitch = nullptr;
    Il2CppMethod* mPlayerHp = nullptr;
    Il2CppMethod* mPlayerAlive = nullptr;
    Il2CppMethod* mPlayerInMatch = nullptr;
    Il2CppMethod* mPlayerNick = nullptr;
    Il2CppMethod* mPlayerWeapon = nullptr;

    // Offline mode: local player lives in OnetapGame/OnetapMovement, not FusionPlayerNet.
    Il2CppObject* gameObj = nullptr;
    Il2CppObject* movement = nullptr;
    Il2CppField*  fldYaw = nullptr;
    Il2CppField*  fldPitch = nullptr;
    void*         setFieldValueFn = nullptr; // il2cpp_field_set_value, if exported

    void* thread = nullptr;
    bool ready = false;
    int gameGen = 0;

    std::vector<PlayerInfo> players;
    PlayerInfo local;
    Il2CppObject* camera = nullptr;
    int screenW = 1920, screenH = 1080;
    float fov = 90;
};

extern void logf2(const char* fmt, ...);
static GameState g;

typedef Il2CppClass* (*fn_arrclass_t)(Il2CppClass*, uint32_t);
typedef Il2CppArray* (*fn_arrnew_t)(Il2CppClass*, uintptr_t);

// Always capture IL2CPP exceptions: a destroyed Unity object raises one, and
// passing nullptr for exc makes the process die inside GameAssembly.dll.
static bool invokeSafe(Il2CppMethod* m, Il2CppObject* obj, void** args) {
    if (!m) return false;
    Il2CppException* exc = nullptr;
    il2cpp_runtime_invoke(m, obj, args, &exc);
    return exc == nullptr;
}
static Il2CppObject* invokeObjSafe(Il2CppMethod* m, Il2CppObject* obj, void** args) {
    if (!m) return nullptr;
    Il2CppException* exc = nullptr;
    Il2CppObject* r = il2cpp_runtime_invoke(m, obj, args, &exc);
    return exc ? nullptr : r;
}

static Il2CppMethod* meth(Il2CppClass* c, const char* name, int argc) {
    return c ? il2cpp_class_get_method_from_name(c, name, argc) : nullptr;
}
static inline bool ok(Il2CppMethod* m) { return m != nullptr; }
static inline bool finite3(const Vector3& v) {
    return std::isfinite(v.x) && std::isfinite(v.y) && std::isfinite(v.z);
}

static bool initGame(HMODULE game, int w, int h) {
    if (!loadIl2Cpp(game)) return false;
    g.game = game;
    g.screenW = w; g.screenH = h;

    void* dom = il2cpp_domain_get();
    if (!dom) return false;
    g.thread = il2cpp_thread_attach(dom);

    g.setFieldValueFn = (void*)GetProcAddress(game, "il2cpp_field_set_value");

    g.clsCamera = getClass("UnityEngine.CoreModule", "UnityEngine", "Camera");
    if (!g.clsCamera) g.clsCamera = getClass("UnityEngine", "UnityEngine", "Camera");
    g.clsPlayer = getClass("Assembly-CSharp", "Onetap", "FusionPlayerNet");
    if (!g.clsCamera) return false;

    g.mCamMain   = meth(g.clsCamera, "get_main", 0);
    g.mCamW2S    = meth(g.clsCamera, "WorldToScreenPoint", 1);
    g.mCamW2SInj = meth(g.clsCamera, "WorldToScreenPoint_Injected", 3);
    g.mCamGetFov = meth(g.clsCamera, "get_fieldOfView", 0);
    g.mCamSetFov = meth(g.clsCamera, "set_fieldOfView", 1);
    g.mCamGetTransform = meth(g.clsCamera, "get_transform", 0);

    if (g.clsPlayer) {
        g.mPlayerLocal   = meth(g.clsPlayer, "get_Local", 0);
        g.mPlayerPos     = meth(g.clsPlayer, "get_Pos", 0);
        g.mPlayerYaw     = meth(g.clsPlayer, "get_Yaw", 0);
        g.mPlayerPitch   = meth(g.clsPlayer, "get_Pitch", 0);
        g.mPlayerSetYaw  = meth(g.clsPlayer, "set_Yaw", 1);
        g.mPlayerSetPitch= meth(g.clsPlayer, "set_Pitch", 1);
        g.mPlayerHp      = meth(g.clsPlayer, "get_Hp", 0);
        g.mPlayerAlive   = meth(g.clsPlayer, "get_Alive", 0);
        g.mPlayerInMatch = meth(g.clsPlayer, "get_InMatch", 0);
        g.mPlayerNick    = meth(g.clsPlayer, "get_NickText", 0);
        g.mPlayerWeapon  = meth(g.clsPlayer, "get_Weapon", 0);
        g.fldAll = il2cpp_class_get_field_from_name(g.clsPlayer, "All");
    }

    logf2("[il2cpp] init clsCam=%p w2sInj=%p clsPlayer=%p getLocal=%p setField=%p",
          (void*)g.clsCamera, (void*)g.mCamW2SInj, (void*)g.clsPlayer,
          (void*)g.mPlayerLocal, g.setFieldValueFn);
    g.ready = g.clsCamera && g.mCamW2S;
    return g.ready;
}

// ------------------------------------------------------------ generic field helpers
static inline Il2CppObject* getFieldObj(Il2CppObject* obj, const char* name, uintptr_t rawOff) {
    if (!obj) return nullptr;
    Il2CppObject* r = nullptr;
    Il2CppField* f = il2cpp_class_get_field_from_name(il2cpp_object_get_class(obj), name);
    if (f) il2cpp_field_get_value(obj, f, &r);
    else   r = *(Il2CppObject**)((uintptr_t)obj + rawOff);
    if (!r || (uintptr_t)r < 0x10000) return nullptr;
    return r;
}
static inline float getFieldFloat(Il2CppObject* obj, const char* name, uintptr_t rawOff, float fallback = 0.f) {
    if (!obj) return fallback;
    float v = fallback;
    Il2CppField* f = il2cpp_class_get_field_from_name(il2cpp_object_get_class(obj), name);
    if (f) il2cpp_field_get_value(obj, f, &v);
    else   v = *(float*)((uintptr_t)obj + rawOff);
    return std::isfinite(v) ? v : fallback;
}
static inline int getFieldInt(Il2CppObject* obj, const char* name, uintptr_t rawOff, int fallback = 0) {
    if (!obj) return fallback;
    int v = fallback;
    Il2CppField* f = il2cpp_class_get_field_from_name(il2cpp_object_get_class(obj), name);
    if (f) il2cpp_field_get_value(obj, f, &v);
    else   v = *(int*)((uintptr_t)obj + rawOff);
    return v;
}
static inline void setFieldFloat(Il2CppObject* obj, Il2CppField* f, uintptr_t rawOff, float v) {
    if (!obj) return;
    if (g.setFieldValueFn && f) {
        // API signature: il2cpp_field_set_value(obj, field, value) — obj FIRST.
        typedef void (__cdecl *fn_set)(void* obj, Il2CppField* field, void* value);
        ((fn_set)g.setFieldValueFn)(obj, f, &v);
    } else {
        *(float*)((uintptr_t)obj + rawOff) = v;
    }
}

static inline void* classTypeObject(Il2CppClass* cls) {
    typedef void* (*fn_gettype)(void*);
    typedef void* (*fn_typeobj)(void*);
    static fn_gettype fgt = nullptr;
    static fn_typeobj fto = nullptr;
    if (!fgt) fgt = (fn_gettype)GetProcAddress(g_game, "il2cpp_class_get_type");
    if (!fto) fto = (fn_typeobj)GetProcAddress(g_game, "il2cpp_type_get_object");
    if (!fgt || !fto || !cls) return nullptr;
    void* t = fgt(cls);
    return t ? fto(t) : nullptr;
}

static inline Il2CppObject* findObjectOfType(Il2CppClass* cls) {
    if (!cls) return nullptr;
    Il2CppClass* objCls = getClass("UnityEngine.CoreModule", "UnityEngine", "Object");
    if (!objCls) return nullptr;
    void* typeObj = classTypeObject(cls);
    if (!typeObj) return nullptr;
    for (int argc = 2; argc >= 1; argc--) {
        Il2CppMethod* m = il2cpp_class_get_method_from_name(objCls, "FindObjectOfType", argc);
        if (!m) continue;
        uint8_t inc = 1;
        void* args[2] = { typeObj, &inc };
        Il2CppObject* r = invokeObjSafe(m, nullptr, args);
        if (r) return r;
    }
    return nullptr;
}

// Locate the offline game manager and the local player's movement component.
// Both are re-resolved periodically: Unity destroys/recreates them on death
// and respawn, and a stale native pointer crashes inside GameAssembly.
static void ensureGame() {
    static DWORD lt = 0;
    static DWORD lastRebind = 0;
    if (g.gameObj && g.movement && GetTickCount() - lastRebind < 500) return;
    lastRebind = GetTickCount();
    Il2CppClass* gameCls = getClass("Assembly-CSharp", "Onetap", "OnetapGame");
    if (!gameCls) return;
    Il2CppObject* fresh = findObjectOfType(gameCls);
    if (g.gameObj != fresh) { g.gameObj = fresh; ++g.gameGen; g.movement = nullptr; }
    if (!g.gameObj) {
        if (GetTickCount() - lt > 3000) { lt = GetTickCount(); logf2("[game] OnetapGame not found yet"); }
        return;
    }
    g.movement = getFieldObj(g.gameObj, "movement", off::GameMovement);
    if (g.movement) {
        g.fldYaw   = il2cpp_class_get_field_from_name(il2cpp_object_get_class(g.movement), "yaw");
        g.fldPitch = il2cpp_class_get_field_from_name(il2cpp_object_get_class(g.movement), "pitch");
    }
    if (GetTickCount() - lt > 3000) {
        lt = GetTickCount();
        logf2("[game] game=%p movement=%p fYaw=%p fPitch=%p",
              (void*)g.gameObj, (void*)g.movement, (void*)g.fldYaw, (void*)g.fldPitch);
    }
}

static Il2CppObject* getLocal() {
    if (!g.mPlayerLocal) return nullptr;
    return invokeObjSafe(g.mPlayerLocal, nullptr, nullptr);
}

static Vector3 getPos(Il2CppObject* p) {
    Vector3 v{};
    if (!p || !g.mPlayerPos) return v;
    void* args[1] = { &v };
    invokeSafe(g.mPlayerPos, p, args);
    return v;
}

static float getFloat(Il2CppMethod* m, Il2CppObject* p) {
    float v = 0;
    if (!p || !m) return v;
    void* args[1] = { &v };
    invokeSafe(m, p, args);
    return v;
}
static int getInt(Il2CppMethod* m, Il2CppObject* p) {
    int v = 0;
    if (!p || !m) return v;
    void* args[1] = { &v };
    invokeSafe(m, p, args);
    return v;
}
static bool getBool(Il2CppMethod* m, Il2CppObject* p) {
    uint8_t v = 0;
    if (!p || !m) return false;
    void* args[1] = { &v };
    invokeSafe(m, p, args);
    return v != 0;
}
static void setFloat(Il2CppMethod* m, Il2CppObject* p, float v) {
    if (!p || !m) return;
    void* args[1] = { &v };
    invokeSafe(m, p, args);
}
static std::string strOf(Il2CppString* s) {
    if (!s || s->length < 0 || s->length > 128) return {};
    int n = WideCharToMultiByte(CP_UTF8, 0, (const wchar_t*)s->chars, s->length, nullptr, 0, nullptr, nullptr);
    if (n <= 0) return {};
    std::string out((size_t)n, '\0');
    WideCharToMultiByte(CP_UTF8, 0, (const wchar_t*)s->chars, s->length, &out[0], n, nullptr, nullptr);
    return out;
}

static std::string getStr(Il2CppObject* p, Il2CppMethod* m) {
    if (!p || !m) return {};
    Il2CppString* s = (Il2CppString*)invokeObjSafe(m, p, nullptr);
    if (!s) return {};
    int len = s->length;
    if (len < 0 || len > 64) return {};
    std::string out;
    for (int i = 0; i < len; i++) out.push_back((char)s->chars[i]);
    return out;
}

// Camera transform world position, used as the local player's eye origin.
static Vector3 getCamPos(Il2CppObject* cam) {
    Vector3 out{};
    if (!cam || !g.mCamGetTransform) return out;
    Il2CppObject* tr = invokeObjSafe(g.mCamGetTransform, cam, nullptr);
    if (!tr) return out;
    static Il2CppMethod* getPosInj = nullptr;
    if (!getPosInj) {
        Il2CppClass* trCls = getClass("UnityEngine.CoreModule", "UnityEngine", "Transform");
        if (trCls) getPosInj = il2cpp_class_get_method_from_name(trCls, "get_position_Injected", 1);
    }
    if (getPosInj) {
        void* args[1] = { &out };
        invokeSafe(getPosInj, tr, args);
    }
    return out;
}

// Camera forward vector (direct methodPointer, verified in-game).
static Vector3 getCamForward(Il2CppObject* cam) {
    Vector3 out{};
    if (!cam || !g.mCamGetTransform) return out;
    Il2CppObject* tr = invokeObjSafe(g.mCamGetTransform, cam, nullptr);
    if (!tr) return out;
    Il2CppClass* trCls = getClass("UnityEngine.CoreModule", "UnityEngine", "Transform");
    Il2CppMethod* mf = trCls ? il2cpp_class_get_method_from_name(trCls, "get_forward", 0) : nullptr;
    void* mp = mf ? methodPtr(mf) : nullptr;
    if (mp) {
        typedef void (__cdecl *fn_fwd)(Vector3* ret, void* self, void* mInfo);
        ((fn_fwd)mp)(&out, tr, (void*)mf);
    }
    return out;
}

// World -> screen.
// Verified in-game with a known point 10 m directly in front of the camera:
// the public method called via methodPointer returns exactly (960, 540, 10).
// WorldToScreenPoint_Injected via runtime_invoke returns garbage in this build
// (x/z are view-space, not pixels), so it must NOT be used.
static Vector3 w2s(Il2CppObject* cam, Vector3 world) {
    Vector3 res{};
    if (!cam || !g.mCamW2S || !finite3(world)) return res;
    void* mp = methodPtr(g.mCamW2S);
    if (!mp) return res;
    // x64 IL2CPP/MSVC: Vector3 (12 bytes) is passed by hidden pointer,
    // the value type result via sret pointer, methodInfo last.
    typedef void (__cdecl *fn_w2s)(Vector3* ret, void* self, Vector3* pos, void* mInfo);
    ((fn_w2s)mp)(&res, cam, &world, (void*)g.mCamW2S);
    if (!finite3(res) || fabsf(res.x) > 100000.f || fabsf(res.y) > 100000.f) return {};
    return res;
}

// read static List<FusionPlayerNet> All (used only in Fusion online mode)
static std::vector<Il2CppObject*> getAllPlayers() {
    std::vector<Il2CppObject*> out;
    if (!g.fldAll) return out;
    Il2CppList* list = nullptr;
    il2cpp_field_static_get_value(g.fldAll, &list);
    if (!list || list->size <= 0 || list->size > 128 || !list->items) return out;
    uintptr_t base = (uintptr_t)list->items + off::Il2CppArrayData;
    for (int i = 0; i < list->size; i++) {
        Il2CppObject* p = *(Il2CppObject**)(base + i * sizeof(void*));
        if (p) out.push_back(p);
    }
    return out;
}

static void refreshCamera(float fovOverride) {
    ensureGame();
    Il2CppObject* cam = nullptr;

    // Best source in offline mode: OnetapGame.worldCamera (actual gameplay camera).
    if (g.gameObj) cam = getFieldObj(g.gameObj, "worldCamera", off::GameWorldCam);
    // Second best: the eye camera cached by OnetapMovement.
    if (!cam && g.movement) cam = getFieldObj(g.movement, "eye", off::MovEye);
    // Third: FusionBasicBillboard._currentCam (static).
    if (!cam) {
        Il2CppClass* bill = getClass("Fusion.Unity", "Fusion", "FusionBasicBillboard");
        if (!bill) bill = getClass("Assembly-CSharp", "Fusion", "FusionBasicBillboard");
        if (bill) {
            Il2CppField* fc = il2cpp_class_get_field_from_name(bill, "_currentCam");
            if (fc) {
                Il2CppObject* cached = nullptr;
                il2cpp_field_static_get_value(fc, &cached);
                if (cached && (uintptr_t)cached > 0x10000) cam = cached;
            }
        }
    }
    // Fourth: Camera.main.
    if (!cam && g.mCamMain) cam = invokeObjSafe(g.mCamMain, nullptr, nullptr);
    // Last resort: Camera.GetAllCameras(Camera[]) -> first element.
    if (!cam) {
        Il2CppMethod* getAll = meth(g.clsCamera, "GetAllCameras", 1);
        static fn_arrclass_t fnArrClass = nullptr;
        static fn_arrnew_t   fnArrNew = nullptr;
        if (getAll && g_game) {
            if (!fnArrClass) fnArrClass = (fn_arrclass_t)GetProcAddress(g_game, "il2cpp_array_class_get");
            if (!fnArrNew)   fnArrNew   = (fn_arrnew_t)GetProcAddress(g_game, "il2cpp_array_new");
            if (fnArrClass && fnArrNew) {
                Il2CppClass* arrCls = fnArrClass((Il2CppClass*)g.clsCamera, 1); // rank 1
                if (arrCls) {
                    Il2CppArray* arr = (Il2CppArray*)fnArrNew(arrCls, 8);
                    if (arr) {
                        void* args[1] = { arr };
                        invokeSafe(getAll, nullptr, args);
                        Il2CppObject* first = *(Il2CppObject**)((uintptr_t)arr + off::Il2CppArrayData);
                        if (first && (uintptr_t)first > 0x10000) cam = first;
                    }
                }
            }
        }
    }
    g.camera = cam;

    // FOV: runtime_invoke first, direct methodPointer as a second chance, then 90.
    float fov = 0.f;
    if (g.camera && g.mCamGetFov) {
        void* args[1] = { &fov };
        invokeSafe(g.mCamGetFov, g.camera, args);
        if (!std::isfinite(fov) || fov < 10.f || fov > 179.f) {
            fov = 0.f;
            void* mp = methodPtr(g.mCamGetFov);
            if (mp) {
                typedef float (__cdecl *fn_fov)(void* self, void* methodInfo);
                float d = ((fn_fov)mp)(g.camera, (void*)g.mCamGetFov);
                if (std::isfinite(d) && d >= 10.f && d <= 179.f) fov = d;
            }
        }
    }
    if (!std::isfinite(fov) || fov < 10.f || fov > 179.f) fov = 90.f;
    g.fov = fov;

    if (fovOverride > 0.f && g.mCamSetFov && g.camera) {
        setFloat(g.mCamSetFov, g.camera, fovOverride);
        g.fov = fovOverride;
    }
    static DWORD lt = 0;
    if (GetTickCount() - lt > 3000) {
        lt = GetTickCount();
        logf2("[cam] cam=%p gameWorldCam=%p fov=%.1f", (void*)g.camera,
              g.gameObj ? (void*)getFieldObj(g.gameObj, "worldCamera", off::GameWorldCam) : nullptr, g.fov);
    }
}

// ------------------------------------------------------------ bot collection (Onetap.Target)
static inline void collectBots() {
    ensureGame();
    if (!g.gameObj) return;

    Il2CppObject* tObj = getFieldObj(g.gameObj, "targets", off::GameTargets);
    if (!tObj) return;

    Il2CppClass* tCls = il2cpp_object_get_class(tObj);
    Il2CppField* fL = tCls ? il2cpp_class_get_field_from_name(tCls, "targets") : nullptr;
    Il2CppList* list = nullptr;
    if (fL) il2cpp_field_get_value(tObj, fL, &list);
    if (!list || list->size <= 0 || list->size > 64 || !list->items) return;

    Il2CppClass* trCls = getClass("UnityEngine.CoreModule", "UnityEngine", "Transform");
    Il2CppMethod* getPosInj = trCls ? il2cpp_class_get_method_from_name(trCls, "get_position_Injected", 1) : nullptr;

    uintptr_t data = (uintptr_t)list->items + off::Il2CppArrayData;
    for (int i = 0; i < list->size; i++) {
        Il2CppObject* bot = *(Il2CppObject**)(data + i * sizeof(void*));
        if (!bot) continue;

        PlayerInfo pi;
        pi.obj = bot;
        getField(bot, "spawn", &pi.pos, sizeof(Vector3));
        Il2CppObject* model = nullptr;
        getField(bot, "model", &model, sizeof(void*));
        float hp = 0; getField(bot, "health", &hp, sizeof(float));
        pi.hp = (int)hp;
        pi.visible = true; getField(bot, "enemy", &pi.visible, 1);
        bool active = true; getField(bot, "active", &active, 1);
        pi.alive = active;
        pi.inMatch = active;
        if (!active) continue;

        // ONLY the injected getter through runtime_invoke. The previous direct
        // methodPointer call had an unstable ABI and sometimes returned spawn.
        bool posOk = false;
        if (model && getPosInj) {
            Vector3 tp{};
            void* args[1] = { &tp };
            if (invokeSafe(getPosInj, model, args) &&
                finite3(tp) && fabsf(tp.x) < 10000.f && fabsf(tp.y) < 10000.f && fabsf(tp.z) < 10000.f) {
                pi.pos = tp;
                posOk = true;
            }
        }
        // Dead/despawned targets keep their spawn point but have no live model:
        // drawing a box there would be a false positive.
        if (!posOk) continue;

        // Real skeleton: Target.animator (BotAnimator) exposes nine bone
        // Transforms. Read each world position and project it.
        Il2CppObject* anim = nullptr;
        getField(bot, "animator", &anim, sizeof(void*));
        if (anim && getPosInj && g.camera) {
            static const char* boneNames[9] = {
                "head", "chest", "pelvis", "armLeft", "armRight",
                "thighLeft", "thighRight", "shinLeft", "shinRight"
            };
            int found = 0;
            for (int b = 0; b < 9; b++) {
                Il2CppObject* tr = nullptr;
                getField(anim, boneNames[b], &tr, sizeof(void*));
                if (!tr) continue;
                Vector3 wp{};
                void* ba[1] = { &wp };
                if (!invokeSafe(getPosInj, tr, ba) || !finite3(wp)) continue;
                Vector3 s = w2s(g.camera, wp);
                if (s.z <= 0.01f) continue;
                pi.bonesScreen[b] = { s.x, (float)g.screenH - s.y };
                found++;
            }
            pi.hasBones = found >= 6;
        }

        char nm[32]; snprintf(nm, sizeof(nm), "BOT %d", i + 1); pi.name = nm;
        Il2CppString* titleStr = nullptr;
        getField(bot, "title", &titleStr, sizeof(void*));
        pi.weaponName = strOf(titleStr);

        // Exact ESP box: project real world head and feet positions.
        if (g.camera) {
            Vector3 feet = pi.pos;
            Vector3 head = pi.pos; head.y += off::BotEye;
            Vector3 sf = w2s(g.camera, feet);
            Vector3 sh = w2s(g.camera, head);
            // Unity WorldToScreenPoint: z is distance from camera; z<=0 = behind.
            if (sf.z > 0.01f && sh.z > 0.01f) {
                pi.feetScreen = { sf.x, (float)g.screenH - sf.y };
                pi.headScreen = { sh.x, (float)g.screenH - sh.y };
                pi.hasBox = true;
            }
        }
        g.players.push_back(pi);
    }
    static DWORD lt = 0;
    if (GetTickCount() - lt > 3000) {
        lt = GetTickCount();
        size_t boxed = (size_t)std::count_if(g.players.begin(), g.players.end(),
                          [](const PlayerInfo& p) { return p.hasBox; });
        logf2("[bots] game=%p targets=%p list=%p size=%d getPosInj=%p boxed=%zu",
              (void*)g.gameObj, (void*)tObj, (void*)list, list->size, (void*)getPosInj, boxed);
        for (const auto& p : g.players) {
            if (!p.hasBox) continue;
            logf2("[box] %s pos=(%.2f,%.2f,%.2f) feet=(%.1f,%.1f) head=(%.1f,%.1f) hp=%d",
                  p.name.c_str(), p.pos.x, p.pos.y, p.pos.z,
                  p.feetScreen.x, p.feetScreen.y, p.headScreen.x, p.headScreen.y, p.hp);
            break;
        }
        if (g.movement && g.camera) {
            Vector3 fw = getCamForward(g.camera);
            float yawFw = atan2f(fw.x, fw.z) * 57.2957795f;
            float yawMov = getFieldFloat(g.movement, "yaw", off::MovYaw);
            float d = yawMov - yawFw;
            while (d > 180.f) d -= 360.f; while (d < -180.f) d += 360.f;
            logf2("[yaw] movement=%.2f forward=%.2f diff=%.2f (0 => atan2(x,z) convention OK)", yawMov, yawFw, d);
        }
    }
}

static void refreshPlayers(bool matchOnly) {
    g.players.clear();
    ensureGame();
    Il2CppObject* local = getLocal();

    if (local) {
        PlayerInfo li;
        li.obj = local; li.local = true;
        li.pos = getPos(local);
        li.yaw = getFloat(g.mPlayerYaw, local);
        li.pitch = getFloat(g.mPlayerPitch, local);
        li.hp = getInt(g.mPlayerHp, local);
        li.alive = getBool(g.mPlayerAlive, local);
        li.inMatch = getBool(g.mPlayerInMatch, local);
        li.name = getStr(local, g.mPlayerNick);
        g.local = li;
        g.players.push_back(li);
    } else if (g.movement) {
        // Offline mode: no FusionPlayerNet.Local. Build the local player from
        // OnetapGame/OnetapMovement (yaw/pitch fields) + the camera transform.
        PlayerInfo li;
        li.obj = g.movement; li.local = true;
        li.pos = getCamPos(g.camera);
        li.yaw = getFieldFloat(g.movement, "yaw", off::MovYaw);
        li.pitch = getFieldFloat(g.movement, "pitch", off::MovPitch);
        li.hp = g.gameObj ? getFieldInt(g.gameObj, "health", off::GameHealth) : 100;
        li.alive = li.hp > 0;
        li.inMatch = true;
        li.name = "LOCAL";
        g.local = li;
        g.players.push_back(li);
    } else {
        g.local = PlayerInfo{};
    }

    for (Il2CppObject* p : getAllPlayers()) {
        if (!p || p == local) continue;
        PlayerInfo pi;
        pi.obj = p;
        pi.pos = getPos(p);
        pi.yaw = getFloat(g.mPlayerYaw, p);
        pi.pitch = getFloat(g.mPlayerPitch, p);
        pi.hp = getInt(g.mPlayerHp, p);
        pi.alive = getBool(g.mPlayerAlive, p);
        pi.inMatch = getBool(g.mPlayerInMatch, p);
        pi.name = getStr(p, g.mPlayerNick);
        pi.weapon = getInt(g.mPlayerWeapon, p);
        if (matchOnly && !pi.inMatch) continue;
        g.players.push_back(pi);
    }

    // offline bots from Onetap.Targets
    collectBots();
}

static void projectPlayers() {
    if (!g.camera) return;
    Vector3 origin = g.local.obj ? g.local.pos : getCamPos(g.camera);
    for (auto& p : g.players) {
        Vector3 s = w2s(g.camera, p.pos);
        if (s.z < 0.01f) { p.onScreen = false; continue; }
        p.screen.x = s.x;
        p.screen.y = (float)g.screenH - s.y; // Unity bottom-left -> ImGui top-left
        p.onScreen = s.x >= -50 && s.x <= g.screenW + 50 &&
                     s.y >= -50 && s.y <= g.screenH + 50;
        float dx = p.pos.x - origin.x, dy = p.pos.y - origin.y, dz = p.pos.z - origin.z;
        p.dist = sqrtf(dx*dx + dy*dy + dz*dz);
    }
}


