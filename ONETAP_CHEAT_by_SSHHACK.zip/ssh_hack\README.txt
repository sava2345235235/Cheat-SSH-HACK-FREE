SSH HACK for ONETAP (offline Unity 2022.3 / IL2CPP v31 / D3D11)
================================================================

Запуск:
  1. Запустить ONETAP.exe и зайти в матч / тренировку.
  2. Запустить injector.exe (или: injector.exe "путь\к\ssh_hack.dll").
  3. INSERT — показать/скрыть меню.

Меню:
  RAGE   — Silent Aim (родной HvH движка), автоогонь (выкл. по умолчанию),
           Wall Penetration, Silent Damage, Fly Down + бинд, Anti-Aim/Desync,
           Resolver, Third Person, общий бинд аима и Aim Speed.
  Aim    — Legit aim, Smoothing, No Recoil, Aim Key.
  Visuals— стандартные настройки визуала библиотеки меню.
  ESP    — Box / Skeleton (по реальным костям BotAnimator) / Chams
           (родные чамсы игры, включая скрытые модели за стенами),
           Name / Weapon / Health / Distance / Box Style / Rainbow.
  Settings — настройки библиотеки меню.

Сборка из исходников (требуется MSVC / vcvars64):
  build.bat          -> ssh_hack.dll
  build_injector.bat -> injector.exe

Важно:
  - Пути к меню и ассетам относительные (папка nl_menu рядом с DLL).
    Архив можно распаковать в любую папку — пересобирать не обязательно.
  - Перед пересборкой ssh_hack.dll закрой игру (DLL заблокирована процессом).
  - Лог: ssh.log в этой же папке.
