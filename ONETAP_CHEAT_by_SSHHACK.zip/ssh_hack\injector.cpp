// Standalone DLL injector for ONETAP (no Python required).
// Usage: injector.exe [path\to\ssh_hack.dll]
// If no path is given, ssh_hack.dll next to the EXE is used.
#include <windows.h>
#include <tlhelp32.h>
#include <cstdio>
#include <cstring>
#include <string>

static bool findProcess(const char* name, DWORD& pid) {
    HANDLE snap = CreateToolhelp32Snapshot(TH32CS_SNAPPROCESS, 0);
    if (snap == INVALID_HANDLE_VALUE) return false;
    PROCESSENTRY32 pe{};
    pe.dwSize = sizeof(pe);
    bool found = false;
    if (Process32First(snap, &pe)) {
        do {
            if (_stricmp(pe.szExeFile, name) == 0) { pid = pe.th32ProcessID; found = true; break; }
        } while (Process32Next(snap, &pe));
    }
    CloseHandle(snap);
    return found;
}

static bool hasModule(DWORD pid, const char* moduleName) {
    HANDLE snap = CreateToolhelp32Snapshot(TH32CS_SNAPMODULE | TH32CS_SNAPMODULE32, pid);
    if (snap == INVALID_HANDLE_VALUE) return false;
    MODULEENTRY32 me{};
    me.dwSize = sizeof(me);
    bool found = false;
    if (Module32First(snap, &me)) {
        do {
            if (_stricmp(me.szModule, moduleName) == 0) { found = true; break; }
        } while (Module32Next(snap, &me));
    }
    CloseHandle(snap);
    return found;
}

static bool inject(DWORD pid, const std::string& dll) {
    HANDLE h = OpenProcess(PROCESS_ALL_ACCESS, FALSE, pid);
    if (!h) { std::printf("[-] OpenProcess(%u) failed: %lu\n", pid, GetLastError()); return false; }

    SIZE_T len = dll.size() + 1;
    LPVOID remote = VirtualAllocEx(h, nullptr, len, MEM_COMMIT | MEM_RESERVE, PAGE_READWRITE);
    if (!remote) {
        std::printf("[-] VirtualAllocEx failed: %lu\n", GetLastError());
        CloseHandle(h);
        return false;
    }
    SIZE_T written = 0;
    BOOL ok = WriteProcessMemory(h, remote, dll.c_str(), len, &written);
    if (!ok || written != len) {
        std::printf("[-] WriteProcessMemory failed: %lu\n", GetLastError());
        VirtualFreeEx(h, remote, 0, MEM_RELEASE);
        CloseHandle(h);
        return false;
    }

    HMODULE k32 = GetModuleHandleA("kernel32.dll");
    LPTHREAD_START_ROUTINE load = (LPTHREAD_START_ROUTINE)GetProcAddress(k32, "LoadLibraryA");
    if (!load) { std::printf("[-] GetProcAddress(LoadLibraryA) failed\n"); CloseHandle(h); return false; }

    HANDLE th = CreateRemoteThread(h, nullptr, 0, load, remote, 0, nullptr);
    if (!th) {
        std::printf("[-] CreateRemoteThread failed: %lu\n", GetLastError());
        VirtualFreeEx(h, remote, 0, MEM_RELEASE);
        CloseHandle(h);
        return false;
    }
    WaitForSingleObject(th, 10000);
    CloseHandle(th);
    VirtualFreeEx(h, remote, 0, MEM_RELEASE);
    CloseHandle(h);
    return true;
}

int main(int argc, char** argv) {
    std::string dll;
    if (argc > 1) {
        dll = argv[1];
    } else {
        char exe[MAX_PATH]{};
        DWORD n = GetModuleFileNameA(nullptr, exe, MAX_PATH);
        dll = "ssh_hack.dll";
        if (n > 0 && n < MAX_PATH) {
            std::string p(exe, n);
            size_t slash = p.find_last_of("\\/");
            if (slash != std::string::npos) dll = p.substr(0, slash + 1) + "ssh_hack.dll";
        }
    }
    char full[MAX_PATH]{};
    if (!GetFullPathNameA(dll.c_str(), MAX_PATH, full, nullptr)) {
        std::printf("[-] bad DLL path: %s\n", dll.c_str());
        return 1;
    }
    FILE* f = nullptr;
    if (fopen_s(&f, full, "rb") != 0 || !f) {
        std::printf("[-] DLL not found: %s\n", full);
        return 1;
    }
    fclose(f);

    DWORD pid = 0;
    if (!findProcess("ONETAP.exe", pid)) {
        std::printf("[-] ONETAP.exe not running. Start the game first.\n");
        return 1;
    }
    std::printf("[+] found ONETAP.exe PID=%u GameAssembly=%s\n", pid,
                hasModule(pid, "GameAssembly.dll") ? "yes" : "no");
    if (!inject(pid, full)) return 1;
    std::printf("[+] injected: %s\n", full);
    return 0;
}
