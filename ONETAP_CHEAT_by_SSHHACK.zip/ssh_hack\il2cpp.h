#pragma once
#include <windows.h>
#include <cstdint>
#include <cstring>

// ------------------------------------------------------------ IL2CPP API (exported by GameAssembly.dll)
typedef void*          Il2CppDomain;
typedef void*          Il2CppAssembly;
typedef void*          Il2CppImage;
typedef void*          Il2CppClass;
typedef void*          Il2CppMethod;
typedef void*          Il2CppField;
typedef void*          Il2CppObject;
typedef void*          Il2CppThread;

struct Il2CppException;

struct Vector3 { float x, y, z; };
struct Vector2 { float x, y; };

struct Il2CppString {
    void* klass;
    void* monitor;
    int32_t length;
    uint16_t chars[1];
};

struct Il2CppArray {
    void* klass;
    void* monitor;
    uintptr_t bounds;
    uintptr_t max_length;
    // elements follow
};

struct Il2CppList {
    void* klass;
    void* monitor;
    Il2CppArray* items;
    int32_t size;
    int32_t version;
    void* syncRoot;
};

struct Il2CppMethodInfo {
    const char* name;
};

static HMODULE g_game = nullptr;

#define DEFINE_IL2CPP(name, ret, ...) \
    typedef ret (__cdecl *fn_##name)(__VA_ARGS__); \
    static fn_##name name = nullptr

DEFINE_IL2CPP(il2cpp_get_corlib, void*);
DEFINE_IL2CPP(il2cpp_domain_get, Il2CppDomain);
DEFINE_IL2CPP(il2cpp_domain_assembly_open, Il2CppAssembly*, void*, const char*);
DEFINE_IL2CPP(il2cpp_assembly_get_image, Il2CppImage*, Il2CppAssembly*);
DEFINE_IL2CPP(il2cpp_class_from_name, Il2CppClass*, Il2CppImage*, const char*, const char*);
DEFINE_IL2CPP(il2cpp_class_get_method_from_name, Il2CppMethod*, Il2CppClass*, const char*, int);
DEFINE_IL2CPP(il2cpp_class_get_field_from_name, Il2CppField*, Il2CppClass*, const char*);
DEFINE_IL2CPP(il2cpp_field_static_get_value, void, Il2CppField*, void*);
DEFINE_IL2CPP(il2cpp_field_get_value, void, Il2CppObject*, Il2CppField*, void*);
DEFINE_IL2CPP(il2cpp_runtime_invoke, Il2CppObject*, Il2CppMethod*, Il2CppObject*, void**, Il2CppException**);
DEFINE_IL2CPP(il2cpp_thread_attach, void*, void*);
DEFINE_IL2CPP(il2cpp_array_length, uintptr_t, Il2CppArray*);
DEFINE_IL2CPP(il2cpp_array_get, void*, Il2CppArray*, uintptr_t);
DEFINE_IL2CPP(il2cpp_string_new, Il2CppString*, const char*);
DEFINE_IL2CPP(il2cpp_object_get_class, Il2CppClass*, Il2CppObject*);
DEFINE_IL2CPP(il2cpp_class_get_methods, Il2CppMethod*, Il2CppClass*, void**);
DEFINE_IL2CPP(il2cpp_method_get_name, const char*, Il2CppMethod*);

// some exports are named slightly differently across versions; resolve both
static inline bool loadIl2Cpp(HMODULE game) {
    g_game = game;
#define RES(name) name = (fn_##name)GetProcAddress(game, #name); if(!name) return false
    RES(il2cpp_get_corlib);
    RES(il2cpp_domain_get);
    RES(il2cpp_domain_assembly_open);
    RES(il2cpp_assembly_get_image);
    RES(il2cpp_class_from_name);
    RES(il2cpp_class_get_method_from_name);
    RES(il2cpp_class_get_field_from_name);
    RES(il2cpp_field_static_get_value);
    RES(il2cpp_field_get_value);
    RES(il2cpp_runtime_invoke);
    RES(il2cpp_thread_attach);
    RES(il2cpp_array_length);
    RES(il2cpp_string_new);
    RES(il2cpp_object_get_class);
    RES(il2cpp_class_get_methods);
    RES(il2cpp_method_get_name);
#undef RES
    // array_get may be exported as il2cpp_array_get; if missing compute manually
    if (!il2cpp_array_get)
        il2cpp_array_get = (fn_il2cpp_array_get)GetProcAddress(game, "il2cpp_array_get");
    return true;
}

// ------------------------------------------------------------ helpers
static inline Il2CppClass* getClass(const char* asmName, const char* ns, const char* cls) {
    if (!il2cpp_domain_assembly_open || !il2cpp_domain_get) return nullptr;
    void* dom = il2cpp_domain_get();
    Il2CppAssembly* a = il2cpp_domain_assembly_open(dom, asmName);
    if (!a) return nullptr;
    Il2CppImage* img = il2cpp_assembly_get_image(a);
    if (!img) return nullptr;
    return il2cpp_class_from_name(img, ns, cls);
}

static inline Il2CppObject* invoke(Il2CppMethod* m, Il2CppObject* obj, void** args) {
    if (!m) return nullptr;
    return il2cpp_runtime_invoke(m, obj, args, nullptr);
}

// invoke a method returning a value type (Vector3/float/int); result goes into ret buffer
static inline void invokeValue(Il2CppMethod* m, Il2CppObject* obj, void** args, void* ret, size_t retSize) {
    if (!m) return;
    // IL2CPP passes return-by-value as first arg slot (thiscall convention with sret)
    void* all[8];
    int n = 0;
    if (ret) all[n++] = ret;
    if (args) { for (int i = 0; args[i] && i < 6; i++) all[n++] = args[i]; }
    all[n] = nullptr;
    il2cpp_runtime_invoke(m, obj, all, nullptr);
}

static inline bool getField(Il2CppObject* obj, const char* name, void* out, size_t sz) {
    if (!obj || !il2cpp_class_get_field_from_name) return false;
    Il2CppClass* c = il2cpp_object_get_class(obj);
    Il2CppField* f = il2cpp_class_get_field_from_name(c, name);
    if (!f) return false;
    il2cpp_field_get_value(obj, f, out);
    return true;
}
