# Готовые читы для ONETAP

Папка содержит две рабочие сборки под офлайн-игру **ONETAP** (Unity 2022.3 / IL2CPP).
Обе проверены в игре. Использовать лучше **по одному** — одновременно инжектить не надо.

## Состав

| Папка | Что это |
| --- | --- |
| `togh_esp` | Внешний ESP от togh, переделанный под ONETAP. Визуал оригинальный: бокс, скелет, HP, имя, дистанция, снаплайн. |
| `ssh_hack` | SSH Hack для ONETAP: одна вкладка ESP (Enabled/Box/Skeleton/Chams/Name/Weapon/Health/Style/Distance/Rainbow/Visible Only). |

В каждой папке есть `injector.exe`, готовая DLL, исходники и свой README.

## Как запустить

1. Запустить `F:\onetap_SSH\ONETAP_1.0.2.1\ONETAP.exe`.
2. Зайти в матч / тренировку (в главном меню ботов нет).
3. Запустить `injector.exe` из нужной папки — он сам найдёт процесс `ONETAP.exe`.
   Либо явно: `injector.exe "F:\ONETAP_CHEATS\togh_esp\togh_onetap.dll"`.
4. Готово.

### togh_esp

- **INSERT** — меню настроек togh (цвета, толщина, шрифт, ESP-элементы, статус).
- **F8** — вкл/выкл ESP.
- **END** — выключить отрисовку.
- Пересборка: `build.bat` → `togh_onetap.dll`.
- Лог: `C:\Users\dwad1\AppData\Local\Temp\opencode\onetap_togh.log`

### ssh_hack

- **INSERT** — показать/скрыть меню (одна вкладка ESP).
- ESP включён по умолчанию.
- Пересборка: `build.bat` (или solution `ssh_hack_ONETAP.sln` в Visual Studio).
- Лог: `C:\Users\dwad1\AppData\Local\Temp\opencode\onetap_ssh\ssh.log`

## Важное

- Это офлайн-игра с ботами — реальным игрокам урона нет.
- Если игра обновится (новая версия `GameAssembly.dll`), оффсеты внутри IL2CPP-моста могут потребовать правки — исходники включены.
- Скриншоты проверки: `togh_esp\esp_work.png`, `togh_esp\final_check.png`.

## Проверка

В логе togh при запуске должна быть строка:
```
[w2s] unity=(960.0,540.0,10.0) mine=(960.0,540.0) w=10.00 fov=60.0
```
Это значит, что проекция ESP совпадает с родной камерой игры. В матче:
```
[esp] players=6 drawn=6
```
