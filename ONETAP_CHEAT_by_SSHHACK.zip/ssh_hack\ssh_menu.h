#pragma once
// NL menu bridge — replaces the old ImGui-only ssh_menu window.
#include "config.h"
#include "game.h"
#include <imgui/imgui.h>
#include <algorithm>
#include "menu/menu.h"
#include "menu/fonts.h"

namespace sshmenu {

static nl::Menu g_menu;
static bool    g_menuInited = false;
static bool    g_fontsLoaded = false;
static bool    g_prevShow = true;
static const int k_vkKeys[8] = { VK_RBUTTON, VK_LBUTTON, VK_SHIFT, VK_CONTROL, VK_MENU, 'X', 'C', 'V' };

// Must be called right after ImGui::CreateContext(), before the first NewFrame.
static void loadFonts() {
    if (g_fontsLoaded) return;
    nl::load_fonts();
    g_fontsLoaded = true;
}

static void init() {
    if (g_menuInited) return;
    loadFonts();
    g_menu.init(ImVec2(80.f, 40.f), 1.0f);
    g_menu.set_tab(0, 0); // RAGE tab first
    g_menu.set_visible(g_cfg.showMenu);

    nl::Config& c = g_menu.config();
    c.legit.enabled = true;
    c.legit.field_of_view = 60.f;
    c.legit.aimKey = 0;
    c.rage.enabled = true;
    c.rage.silent_aim = true;
    c.rage.auto_fire = false;
    c.rage.aim_fov = 35.f;
    c.rage.aim_speed = 100.f;
    c.rage.reaction_time = 90.f;
    c.rage.anti_aim = false;
    c.rage.desync = false;
    c.rage.thirdPerson = false;
    c.rage.thirdDistance = 3.f;
    c.rage.aimKey = 0;             // Right Mouse
    c.rage.wall_penetration = true;
    c.rage.silent_damage = 120.f;
    c.rage.fly_down = false;
    c.rage.fly_key = 2;            // Shift
    c.rage.resolver = true;
    c.rage.resolver_mode = 1;

    c.espUi.enabled = true;
    c.espUi.box = true;
    c.espUi.skeleton = false;  // separate toggle, off by default
    c.espUi.chams = true;   // native chams + chamsHidden (through walls)
    c.espUi.name = true;
    c.espUi.weapon = true;
    c.espUi.health = true;
    c.espUi.distance = true;
    c.espUi.rainbow = false;
    c.espUi.box_style = 0;

    g_prevShow = g_cfg.showMenu;
    g_menuInited = true;
}

static void syncConfig() {
    if (!g_menuInited) return;
    nl::Config& c = g_menu.config();
    const nl::RageSettings& r = c.rage;
    const nl::EspUi& e = c.espUi;

    // Aim: only one active at a time (RAGE wins when enabled).
    g_cfg.aimEnabled     = c.legit.enabled && !r.enabled;
    g_cfg.aimFov         = std::clamp(c.legit.field_of_view, 1.f, 180.f);
    g_cfg.aimSmooth      = std::clamp(1.f + c.legit.smoothing / 10.f, 1.f, 20.f);
    g_cfg.espVisibleOnly = c.legit.visible_only;
    g_cfg.noRecoil       = c.legit.no_recoil;

    // Dedicated ESP tab.
    g_cfg.espEnabled   = e.enabled;
    g_cfg.espBox       = e.box;
    g_cfg.espSkeleton  = e.skeleton;
    g_cfg.chams        = e.chams;
    g_cfg.espName      = e.name;
    g_cfg.espWeapon    = e.weapon;
    g_cfg.espHealth    = e.health;
    g_cfg.espDistance  = e.distance;
    g_cfg.rainbow      = e.rainbow;
    g_cfg.espBoxStyle  = e.box_style;
    g_cfg.colEnemy     = ImGui::ColorConvertFloat4ToU32(e.color);

    // RAGE tab.
    g_cfg.rageEnabled     = r.enabled;
    g_cfg.rageSilent      = r.silent_aim;
    g_cfg.rageAutoFire    = r.auto_fire;
    g_cfg.rageFov         = std::clamp(r.aim_fov, 1.f, 180.f);
    g_cfg.rageSpeed       = std::clamp(r.aim_speed, 0.f, 100.f);
    g_cfg.rageFireDelay   = std::clamp(r.reaction_time, 0.f, 500.f);
    g_cfg.wallPenetration = r.wall_penetration;
    g_cfg.silentDamage    = std::clamp(r.silent_damage, 10.f, 200.f);
    g_cfg.flyDown         = r.fly_down;
    g_cfg.flyKey          = k_vkKeys[std::clamp(r.fly_key, 0, 7)];
    g_cfg.antiAim         = r.anti_aim;
    g_cfg.antiAimYawMode  = r.yaw;
    g_cfg.antiAimPitchMode= r.pitch;
    g_cfg.antiAimYawOffset= r.yaw_offset;
    g_cfg.desync          = r.desync;
    g_cfg.resolver        = r.resolver;
    g_cfg.resolverMode    = r.resolver_mode;
    g_cfg.thirdPerson     = r.thirdPerson;
    g_cfg.thirdDistance   = r.thirdDistance;

    int keyIdx = r.enabled ? r.aimKey : c.legit.aimKey;
    g_cfg.aimKey = k_vkKeys[std::clamp(keyIdx, 0, 7)];
}

// Branding lives only in the menu's own right-side watermark (SH / SSH HACK).
static void render() {
    if (!g_menuInited) init();
    if (g_prevShow != g_cfg.showMenu) {
        g_menu.set_visible(g_cfg.showMenu);
        g_prevShow = g_cfg.showMenu;
    }
    syncConfig();
    g_menu.render();
}

static void shutdown() {
    if (!g_menuInited) return;
    g_menu.shutdown();
    g_menuInited = false;
}

} // namespace sshmenu
