#pragma once
#include "config.h"
#include "game.h"
#include <cmath>
#include <algorithm>

namespace aim {

static float normAngle(float a) {
    while (a > 180.f) a -= 360.f;
    while (a < -180.f) a += 360.f;
    return a;
}

// Offline ONETAP has no FusionPlayerNet.Local. The real local view lives in
// OnetapGame.movement (OnetapMovement) with private yaw/pitch fields at
// 0x58/0x5C. We write those fields directly; the game's Update() applies them
// to the camera on the next frame.
static void run() {
    if (!g_cfg.aimEnabled || !g.ready) return;
    ensureGame();

    static bool prevKey = false;
    static bool toggled = false;
    bool key = keyHeld(g_cfg.aimKey);
    if (g_cfg.aimToggle) {
        if (key && !prevKey) toggled = !toggled;
    } else {
        toggled = key;
    }
    prevKey = key;
    if (!toggled) return;

    if (!g.local.obj || !g.local.alive) return;

    // Eye origin. In offline mode g.local.pos is already the camera position.
    Vector3 eye = g.local.pos;
    if (g.local.obj != g.movement) {
        eye.y += off::StandEye;
    }
    float curYaw   = g.local.yaw;
    float curPitch = g.local.pitch;
    if (g.movement) {
        curYaw   = getFieldFloat(g.movement, "yaw",   off::MovYaw);
        curPitch = getFieldFloat(g.movement, "pitch", off::MovPitch);
    }
    if (!std::isfinite(curYaw) || !std::isfinite(curPitch)) return;

    PlayerInfo* target = nullptr;
    float best = g_cfg.aimFov;

    for (auto& p : g.players) {
        if (p.local || !p.alive || !p.hasBox) continue;
        if (g_cfg.espMaxDist > 0 && p.dist > g_cfg.espMaxDist) continue;

        Vector3 aimPoint{ p.pos.x, p.pos.y + off::BotEye, p.pos.z };
        float dx = aimPoint.x - eye.x;
        float dy = aimPoint.y - eye.y;
        float dz = aimPoint.z - eye.z;
        float horiz = sqrtf(dx*dx + dz*dz);
        if (horiz < 0.05f) continue;

        // Unity convention: forward = (sin(yaw)*cos(pitch), -sin(pitch), cos(yaw)*cos(pitch)).
        float targetYaw   = atan2f(dx, dz) * 57.2957795f;
        float targetPitch = -atan2f(dy, horiz) * 57.2957795f;
        float dYaw   = fabsf(normAngle(targetYaw - curYaw));
        float dPitch = fabsf(normAngle(targetPitch - curPitch));
        float score = g_cfg.aimNearest ? (dYaw + dPitch) : p.dist;
        if (score < best) { best = score; target = &p; }
    }
    if (!target) return;

    Vector3 aimPoint{ target->pos.x, target->pos.y + off::BotEye, target->pos.z };
    float dx = aimPoint.x - eye.x;
    float dy = aimPoint.y - eye.y;
    float dz = aimPoint.z - eye.z;
    float horiz = sqrtf(dx*dx + dz*dz);
    float targetYaw   = atan2f(dx, dz) * 57.2957795f;
    float targetPitch = -atan2f(dy, horiz) * 57.2957795f;

    float ny = normAngle(targetYaw - curYaw);
    float np = normAngle(targetPitch - curPitch);

    float smooth = g_cfg.aimSmooth < 1.f ? 1.f : g_cfg.aimSmooth;
    if (smooth > 1.f) { ny /= smooth; np /= smooth; }

    float newYaw   = curYaw + ny;
    float newPitch = std::clamp(curPitch + np, -89.f, 89.f);

    static DWORD lastLog = 0;
    if (GetTickCount() - lastLog > 700) {
        lastLog = GetTickCount();
        logf2("[aim] %s cur=(%.1f,%.1f) want=(%.1f,%.1f) write=(%.1f,%.1f) dist=%.1f",
              target->name.c_str(), curYaw, curPitch, targetYaw, targetPitch, newYaw, newPitch, target->dist);
    }

    if (g.movement) {
        setFieldFloat(g.movement, g.fldYaw,   off::MovYaw,   newYaw);
        setFieldFloat(g.movement, g.fldPitch, off::MovPitch, newPitch);
    } else {
        // Online/Fusion fallback: use the networked setters.
        if (g.mPlayerSetYaw)   setFloat(g.mPlayerSetYaw,   g.local.obj, newYaw);
        if (g.mPlayerSetPitch) setFloat(g.mPlayerSetPitch, g.local.obj, newPitch);
    }
    g.local.yaw = newYaw;
    g.local.pitch = newPitch;
}

} // namespace aim
