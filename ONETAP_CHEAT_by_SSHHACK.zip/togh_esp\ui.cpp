#include "ui.h"
#include "config.h" // Подключаем конфиг здесь
#include "imgui.h"

namespace {

void ColorEditU32(const char* label, ImU32& color) {
    const ImVec4 current = ImGui::ColorConvertU32ToFloat4(color);
    float rgba[4] = { current.x, current.y, current.z, current.w };
    if (ImGui::ColorEdit4(label, rgba, ImGuiColorEditFlags_AlphaBar)) {
        color = ImGui::ColorConvertFloat4ToU32(ImVec4(rgba[0], rgba[1], rgba[2], rgba[3]));
    }
}

}  // namespace

void DrawMenu(Config& cfg, const MenuInfo& info) {
    ImGui::SetNextWindowPos(ImVec2(60.0f, 60.0f), ImGuiCond_FirstUseEver);
    ImGui::Begin("togh esp", nullptr, ImGuiWindowFlags_AlwaysAutoResize | ImGuiWindowFlags_NoCollapse);

    ImGui::Checkbox("ESP включён  [F8]", &cfg.enabled);
    ImGui::Checkbox("Только враги", &cfg.teamCheck);

    ImGui::SeparatorText("Отрисовка");
    ImGui::Checkbox("Бокс", &cfg.drawBox);
    ImGui::SameLine();
    ImGui::Checkbox("HP", &cfg.drawHealth);
    ImGui::SameLine();
    ImGui::Checkbox("Ник", &cfg.drawName);
    ImGui::Checkbox("Дистанция", &cfg.drawDistance);
    ImGui::SameLine();
    ImGui::Checkbox("Снаплайн", &cfg.drawSnapline);
    ImGui::Checkbox("Скелет", &cfg.drawSkeleton);
    ImGui::Checkbox("Цвет по spotted (виден врагам)", &cfg.spottedColor);

    ImGui::SeparatorText("Вид");
    ImGui::SliderFloat("Толщина", &cfg.thickness, 0.5f, 4.0f, "%.1f");
    ImGui::SliderFloat("Шрифт", &cfg.fontSize, 10.0f, 26.0f, "%.0f px");
    ImGui::SliderFloat("Макс. дистанция", &cfg.maxDistance, 0.0f, 200.0f, "%.0f m");
    if (cfg.maxDistance < 1.0f) {
        ImGui::SameLine();
        ImGui::TextDisabled("без лимита");
    }

    if (ImGui::CollapsingHeader("Цвета")) {
        ColorEditU32("Враг", cfg.enemyColor);
        ColorEditU32("Враг вне обзора", cfg.enemyHiddenColor);
        ColorEditU32("Свой", cfg.teamColor);
        ColorEditU32("Текст", cfg.textColor);
    }

    ImGui::SeparatorText("Производительность");
    ImGui::SliderInt("Кадров/с (оверлей)", &cfg.targetFps, 30, 240);
    ImGui::SliderInt("Частота чтения памяти", &cfg.dataHz, 20, 240);
    if (ImGui::IsItemHovered()) {
        ImGui::SetTooltip("Сколько раз в секунду перечитывается список игроков.\nНиже = меньше нагрузка на CPU.");
    }

    ImGui::SeparatorText("Статус");
    if (info.attached) {
        ImGui::Text("pid %lu   client.dll 0x%llX", info.pid,
                    static_cast<unsigned long long>(info.clientBase));
    } else {
        ImGui::TextDisabled("процесс cs2.exe не найден");
    }

    if (info.offsetsLoaded) {
        ImGui::Text("игроков: %d   на экране: %d", info.players, info.drawn);
        ImGui::Text("stride 0x%X (score %d)   local pawn 0x%llX",
                    info.stride, info.strideScore, static_cast<unsigned long long>(info.localPawn));
    } else if (!info.offsetsError.empty()) {
        ImGui::TextWrapped("%s", info.offsetsError.c_str());
    }

    ImGui::Text("fps %.0f", info.fps);
    ImGui::Separator();
    ImGui::TextDisabled("Insert — меню   F8 — вкл/выкл ESP   End — выход");

    ImGui::End();
}